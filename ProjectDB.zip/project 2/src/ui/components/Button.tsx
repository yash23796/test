import React from 'react';
import { Button as SaltButton, type ButtonProps as SaltButtonProps } from '@salt-ds/core';

export interface ButtonProps extends Omit<SaltButtonProps, 'variant'> {
  /**
   * Button variant - maps to Salt's appearance and sentiment
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary' | 'cta' | 'outline' | 'ghost';
  /**
   * Button size
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
  /**
   * Icon to display before the button text
   */
  icon?: React.ReactNode;
  /**
   * Icon to display after the button text
   */
  endIcon?: React.ReactNode;
}

/**
 * Button component wrapper around Salt Design System Button
 * Provides a simplified API while using Salt components internally
 */
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'medium', icon, endIcon, children, className, ...props }, ref) => {
    // Map our simplified variant to Salt's appearance and sentiment
    const saltProps: SaltButtonProps = {
      ...props,
      className,
    };

    // Map variant to Salt's appearance and sentiment
    switch (variant) {
      case 'cta':
        saltProps.appearance = 'solid';
        saltProps.sentiment = 'accented';
        break;
      case 'primary':
        saltProps.appearance = 'solid';
        saltProps.sentiment = 'neutral';
        break;
      case 'secondary':
        saltProps.appearance = 'transparent';
        saltProps.sentiment = 'neutral';
        break;
      case 'outline':
        saltProps.appearance = 'bordered';
        saltProps.sentiment = 'neutral';
        break;
      case 'ghost':
        saltProps.appearance = 'transparent';
        saltProps.sentiment = 'neutral';
        break;
    }

    return (
      <SaltButton {...saltProps} ref={ref}>
        {icon && <span style={{ display: 'inline-flex', marginRight: children ? '0.5rem' : 0 }}>{icon}</span>}
        {children}
        {endIcon && <span style={{ display: 'inline-flex', marginLeft: children ? '0.5rem' : 0 }}>{endIcon}</span>}
      </SaltButton>
    );
  }
);

Button.displayName = 'Button';

