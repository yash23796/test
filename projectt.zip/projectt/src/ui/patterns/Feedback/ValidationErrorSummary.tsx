import React from 'react';
import { Card } from '../../components/Card';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { AlertTriangle, CheckCircle } from 'lucide-react';

export interface ValidationErrorSummaryProps {
  /**
   * Number of valid rows
   */
  valid: number;
  /**
   * Total number of rows
   */
  total: number;
  /**
   * Number of errors
   */
  errors: number;
  /**
   * Whether summary is sticky
   * @default true
   */
  sticky?: boolean;
  /**
   * Callback to scroll to errors section
   */
  onJumpToErrors?: () => void;
  /**
   * Callback to re-validate
   */
  onRevalidate?: () => void;
  /**
   * Whether validation is in progress
   * @default false
   */
  isValidating?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * ValidationErrorSummary - Sticky validation summary with counts and actions
 * Provides consistent validation feedback at the top of validation screens
 */
export const ValidationErrorSummary: React.FC<ValidationErrorSummaryProps> = ({
  valid,
  total,
  errors,
  sticky = true,
  onJumpToErrors,
  onRevalidate,
  isValidating = false,
  className
}) => {
  const percentage = total > 0 ? (valid / total) * 100 : 0;
  const hasErrors = errors > 0;

  const content = (
    <Card
      variant="primary"
      className={`px-6 py-4 ${className || ''}`}
      style={{
        border: `2px solid ${hasErrors ? 'var(--salt-color-red-200)' : 'var(--salt-color-green-200)'}`,
        backgroundColor: hasErrors ? 'var(--salt-color-red-50)' : 'var(--salt-color-green-50)',
      }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {hasErrors ? (
            <AlertTriangle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--salt-color-red-600)' }} />
          ) : (
            <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--salt-color-green-600)' }} />
          )}
          <div>
            <div className="flex items-center gap-3">
              <span
                className="text-lg font-semibold"
                style={{ color: hasErrors ? 'var(--salt-color-red-900)' : 'var(--salt-color-green-900)' }}
              >
                {valid} of {total} rows valid
              </span>
              <Badge value={`${percentage.toFixed(1)}%`} />
              {hasErrors && (
                <Badge value={`${errors} errors`} />
              )}
            </div>
            {hasErrors && (
              <p className="text-sm mt-0.5" style={{ color: 'var(--salt-color-red-700)' }}>
                {errors} errors must be fixed before export
                {onJumpToErrors && (
                  <Button
                    variant="ghost"
                    onClick={onJumpToErrors}
                    className="ml-2 h-auto p-0 text-xs"
                  >
                    Jump to errors
                  </Button>
                )}
              </p>
            )}
          </div>
        </div>
        {onRevalidate && (
          <Button
            variant="outline"
            onClick={onRevalidate}
            disabled={isValidating}
          >
            {isValidating ? 'Validating...' : 'Re-validate'}
          </Button>
        )}
      </div>
    </Card>
  );

  if (sticky) {
    return (
      <div className="sticky top-0 z-10 mb-6">
        {content}
      </div>
    );
  }

  return content;
};

