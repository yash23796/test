import React from 'react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';

export interface EmptyStateProps {
  /**
   * Icon to display
   */
  icon?: React.ReactNode;
  /**
   * Title text
   */
  title: string;
  /**
   * Description text
   */
  description?: string;
  /**
   * Primary action button
   */
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'primary' | 'secondary' | 'outline';
  };
  /**
   * Additional className
   */
  className?: string;
}

/**
 * EmptyState - Displays empty state with icon, message, and optional action
 * Uses Salt Card component for consistent styling
 */
export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  action,
  className
}) => {
  return (
    <Card variant="primary" className={`p-12 text-center ${className || ''}`}>
      <div className="flex flex-col items-center">
        {icon && (
          <div className="mb-4" style={{ color: 'var(--salt-color-gray-400)' }}>
            {icon}
          </div>
        )}
        <h3 className="mb-2 font-medium">{title}</h3>
        {description && (
          <p className="text-sm mb-6" style={{ color: 'var(--salt-color-gray-600)' }}>
            {description}
          </p>
        )}
        {action && (
          <Button 
            variant={action.variant || 'primary'}
            onClick={action.onClick}
          >
            {action.label}
          </Button>
        )}
      </div>
    </Card>
  );
};

