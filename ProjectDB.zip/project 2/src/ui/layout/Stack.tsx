import React from 'react';

export interface StackProps {
  /**
   * Stack children
   */
  children: React.ReactNode;
  /**
   * Gap between items
   * @default 'md'
   */
  gap?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'none';
  /**
   * Additional className
   */
  className?: string;
}

const gapMap = {
  xs: 'gap-1',
  sm: 'gap-2',
  md: 'gap-4',
  lg: 'gap-6',
  xl: 'gap-8',
  none: 'gap-0'
};

/**
 * Stack - Consistent vertical spacing helper for groups
 * Uses Tailwind for spacing, Salt theme for colors
 */
export const Stack: React.FC<StackProps> = ({
  children,
  gap = 'md',
  className = ''
}) => {
  return (
    <div className={`flex flex-col ${gapMap[gap]} ${className}`}>
      {children}
    </div>
  );
};

