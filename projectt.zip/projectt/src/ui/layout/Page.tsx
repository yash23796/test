import React from 'react';

export interface PageProps {
  /**
   * Page content
   */
  children: React.ReactNode;
  /**
   * Maximum width
   * @default '6xl'
   */
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '4xl' | '6xl' | 'full';
  /**
   * Padding
   * @default true
   */
  padding?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

const maxWidthMap = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-xl',
  '2xl': 'max-w-2xl',
  '4xl': 'max-w-4xl',
  '6xl': 'max-w-6xl',
  full: 'max-w-full'
};

/**
 * Page - Standard page container with consistent width, padding, and responsive rules
 * Uses Tailwind for layout, Salt theme for colors
 */
export const Page: React.FC<PageProps> = ({
  children,
  maxWidth = '6xl',
  padding = true,
  className = ''
}) => {
  return (
    <div className={`container mx-auto ${padding ? 'px-4 py-8' : ''} ${maxWidthMap[maxWidth]} ${className}`}>
      {children}
    </div>
  );
};

