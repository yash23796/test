import React from 'react';
import { StatusIndicator, type StatusIndicatorProps } from '@salt-ds/core';
import { Card } from './Card';

export type AlertSeverity = 'error' | 'warning' | 'success' | 'info';

export interface AlertProps extends React.ComponentPropsWithoutRef<'div'> {
  /**
   * Alert severity level
   * @default 'info'
   */
  severity?: AlertSeverity;
  /**
   * Alert title
   */
  title?: string;
  /**
   * Alert message/content
   */
  children?: React.ReactNode;
  /**
   * Whether the alert can be dismissed
   * @default false
   */
  dismissible?: boolean;
  /**
   * Callback when alert is dismissed
   */
  onDismiss?: () => void;
}

/**
 * Alert component using Salt Design System components
 * Uses StatusIndicator for severity indication and Card for container
 */
export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ severity = 'info', title, children, dismissible = false, onDismiss, className, ...props }, ref) => {
    // Map our severity to Salt's validation status
    const statusMap: Record<AlertSeverity, StatusIndicatorProps['status']> = {
      error: 'error',
      warning: 'warning',
      success: 'success',
      info: 'info',
    };

    const status = statusMap[severity];

    return (
      <Card
        ref={ref}
        variant="primary"
        className={className}
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0.75rem',
          padding: '1rem',
          ...props.style,
        }}
        {...props}
      >
        <StatusIndicator status={status} style={{ flexShrink: 0, marginTop: '0.125rem' }} />
        <div style={{ flex: 1 }}>
          {title && (
            <div style={{ fontWeight: 600, marginBottom: children ? '0.25rem' : 0, fontSize: '0.875rem' }}>
              {title}
            </div>
          )}
          {children && <div style={{ fontSize: '0.875rem' }}>{children}</div>}
        </div>
        {dismissible && onDismiss && (
          <button
            onClick={onDismiss}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '0.25rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
            aria-label="Dismiss alert"
          >
            ×
          </button>
        )}
      </Card>
    );
  }
);

Alert.displayName = 'Alert';

