import React from 'react';

export interface InlineCellMessageProps {
  /**
   * Helper text to display
   */
  helperText?: string;
  /**
   * Error text to display
   */
  errorText?: string;
  /**
   * Warning text to display
   */
  warningText?: string;
  /**
   * Success text to display
   */
  successText?: string;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * InlineCellMessage - Consistent cell-level helper/error message pattern
 * Provides standardized messaging for table cells
 */
export const InlineCellMessage: React.FC<InlineCellMessageProps> = ({
  helperText,
  errorText,
  warningText,
  successText,
  className
}) => {
  if (!helperText && !errorText && !warningText && !successText) {
    return null;
  }

  const getTextColor = () => {
    if (errorText) return 'var(--salt-color-red-600)';
    if (warningText) return 'var(--salt-color-orange-600)';
    if (successText) return 'var(--salt-color-green-600)';
    return 'var(--salt-color-gray-600)';
  };

  const message = errorText || warningText || successText || helperText;

  return (
    <p 
      className={`text-xs mt-1 ${className || ''}`}
      style={{ color: getTextColor() }}
    >
      {message}
    </p>
  );
};

