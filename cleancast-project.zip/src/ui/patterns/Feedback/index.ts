/**
 * Feedback Patterns
 * 
 * Reusable feedback components for consistent user feedback across the application.
 * These patterns use the src/ui/components wrappers and Salt Design System.
 */

export { ConfirmDiscardDialog, type ConfirmDiscardDialogProps } from './ConfirmDiscardDialog';
export { UploadProgressNotice, type UploadProgressNoticeProps } from './UploadProgressNotice';
export { ValidationErrorSummary, type ValidationErrorSummaryProps } from './ValidationErrorSummary';
export { SuccessState, type SuccessStateProps } from './SuccessState';

