/**
 * UI Abstraction Layer
 * 
 * This module provides a simplified API for Salt Design System components.
 * All components are wrappers around @salt-ds/core components, providing
 * a consistent interface for the application while maintaining Salt's theming.
 */

export { Button, type ButtonProps } from './components/Button';
export { Input, type InputProps } from './components/Input';
export { Select, type SelectProps, type SelectOption } from './components/Select';
export { Card, type CardProps } from './components/Card';
export { Badge, type BadgeProps } from './components/Badge';
export { Alert, type AlertProps, type AlertSeverity } from './components/Alert';
export { Dialog, type DialogProps } from './components/Dialog';
export { Toast, type ToastProps, type ToastSeverity } from './components/Toast';
export { Progress, type ProgressProps } from './components/Progress';
export { Spinner, type SpinnerProps } from './components/Spinner';

