import React from 'react';

export interface InlineFieldMessageProps {
  /**
   * Helper text to display
   */
  helperText?: string;
  /**
   * Error text to display
   */
  errorText?: string;
  /**
   * Whether the field is required
   * @default false
   */
  required?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * InlineFieldMessage - Consistent pattern for field labels with helper/error text
 * Provides standardized layout for form field messaging
 */
export const InlineFieldMessage: React.FC<InlineFieldMessageProps> = ({
  helperText,
  errorText,
  required = false,
  className
}) => {
  return (
    <div className={`space-y-1 ${className || ''}`}>
      {helperText && !errorText && (
        <p className="text-xs" style={{ color: 'var(--salt-color-gray-600)' }}>
          {helperText}
        </p>
      )}
      {errorText && (
        <p className="text-xs" style={{ color: 'var(--salt-color-red-600)' }}>
          {errorText}
        </p>
      )}
      {required && !helperText && !errorText && (
        <p className="text-xs" style={{ color: 'var(--salt-color-gray-500)' }}>
          Required field
        </p>
      )}
    </div>
  );
};

