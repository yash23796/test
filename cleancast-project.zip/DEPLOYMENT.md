# Deployment Guide - Vercel

## Vercel Deployment (Recommended)

Vercel is the best option for React apps with custom domains. It offers:
- ✅ Zero configuration
- ✅ Automatic HTTPS
- ✅ Free custom domains
- ✅ Fast global CDN
- ✅ Automatic deployments on git push

## Quick Setup Steps

1. **Go to Vercel:**
   - Visit https://vercel.com
   - Sign up/Login with your account

2. **Import Project:**
   - Click "Add New Project"
   - Upload your project folder or connect via CLI
   - Vercel will auto-detect the settings:
     - Framework Preset: Vite
     - Build Command: `npm run build`
     - Output Directory: `dist`
   - Click "Deploy"

3. **Your site is live!**
   - Vercel will provide a URL like: `your-project.vercel.app`

## Custom Domain Setup

1. **Add Domain in Vercel:**
   - Go to your project → Settings → Domains
   - Click "Add Domain"
   - Enter your domain (e.g., `cleancast.com`)

2. **Configure DNS:**
   Vercel will show you the DNS records to add:
   ```
   Type: A
   Name: @
   Value: 76.76.21.21
   
   Type: CNAME
   Name: www
   Value: cname.vercel-dns.com
   ```

3. **Add DNS Records:**
   - Go to your domain registrar (GoDaddy, Namecheap, etc.)
   - Add the DNS records Vercel provided
   - Wait for DNS propagation (usually 5-30 minutes)

4. **SSL Certificate:**
   - Vercel automatically provisions SSL certificates
   - Your site will be available at `https://yourdomain.com`

## Project Configuration

The project is already configured for Vercel:
- ✅ Uses `BrowserRouter` (works with custom domains)
- ✅ No base path needed
- ✅ Build output: `dist/`
- ✅ React Router configured correctly

## Manual Deployments

- Deploy manually through Vercel dashboard or CLI
- Use `vercel` command for deployments
- Instant rollbacks if needed

## Environment Variables (if needed)

If you add environment variables later:
1. Go to Project → Settings → Environment Variables
2. Add your variables
3. Redeploy

## Support

- Vercel Docs: https://vercel.com/docs
- Vercel Support: https://vercel.com/support
