import React from 'react';
import { Dialog } from '../../components/Dialog';

export interface ConfirmDiscardDialogProps {
  /**
   * Whether dialog is open
   */
  open: boolean;
  /**
   * Callback when open state changes
   */
  onOpenChange: (open: boolean) => void;
  /**
   * Callback when user confirms discard
   */
  onConfirm: () => void;
  /**
   * Title text
   * @default 'Discard changes?'
   */
  title?: string;
  /**
   * Description text
   */
  description?: string;
  /**
   * Context-specific message (e.g., 'mapping', 'validation')
   */
  context?: string;
  /**
   * Confirm button text
   * @default 'Discard'
   */
  confirmText?: string;
}

/**
 * ConfirmDiscardDialog - Standardized confirmation dialog for unsaved changes
 * Uses Salt Dialog with consistent destructive action styling
 */
export const ConfirmDiscardDialog: React.FC<ConfirmDiscardDialogProps> = ({
  open,
  onOpenChange,
  onConfirm,
  title = 'Discard changes?',
  description,
  context = 'changes',
  confirmText = 'Discard'
}) => {
  const defaultDescription = description || `Your ${context} will be lost if you continue. This action cannot be undone.`;

  const handleConfirm = () => {
    onConfirm();
    onOpenChange(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
      title={title}
      status="warning"
      size="small"
      primaryAction={{
        label: confirmText,
        onClick: handleConfirm,
        variant: 'primary'
      }}
      secondaryAction={{
        label: 'Cancel',
        onClick: () => onOpenChange(false),
        variant: 'outline'
      }}
    >
      <p>{defaultDescription}</p>
    </Dialog>
  );
};

