import React, { useState } from 'react';
import { Text, H3, H4, Tag, InteractableCardGroup, InteractableCard, StackLayout } from '@salt-ds/core';
import { 
  UploadIcon, 
  FolderClosedIcon, 
  DocumentIcon, 
  BankCheckIcon,
  UserGroupIcon,
  InboxIcon,
  CartIcon,
  ChevronDownIcon,
  CheckmarkIcon
} from '@salt-ds/icons';
import { Button, Card } from '../ui';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { BankTemplate } from '../App';
import { ConfirmDiscardDialog } from '../ui/patterns/Feedback';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

// Salt-style Check Indicator component - positioned at top right with checkmark
interface RadioIndicatorProps {
  selected: boolean;
}

function RadioIndicator({ selected }: RadioIndicatorProps) {
  if (!selected) return null;
  
  return (
    <div
      aria-hidden="true"
      style={{
        position: 'absolute',
        top: '16px',
        right: '16px',
        width: '24px',
        height: '24px',
        minWidth: '24px',
        minHeight: '24px',
        borderRadius: '50%',
        backgroundColor: 'var(--salt-color-accent-foreground)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        transition: 'all 0.15s ease',
        zIndex: 10,
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
        borderColor: 'rgba(27, 127, 158, 1)',
        borderImage: 'none',
        borderWidth: '12px',
        color: 'rgba(255, 255, 255, 1)',
        fontSize: '14px',
        fontWeight: 'bold',
        lineHeight: 1
      }}
    >
      ✓
    </div>
  );
}

interface TemplateStepProps {
  onNext: () => void;
  onBack: () => void;
  selectedTemplate: BankTemplate | null;
  setSelectedTemplate: (template: BankTemplate) => void;
}

interface TemplateWithMeta extends BankTemplate {
  description: string;
  bestFor: string;
}

interface TemplateCategory {
  id: string;
  name: string;
  icon: React.ElementType;
  description: string;
  templates: TemplateWithMeta[];
}

const templateCategories: TemplateCategory[] = [
  {
    id: 'banking',
    name: 'Banking & Finance',
    icon: BankCheckIcon,
    description: 'Payment processing and financial transfers',
    templates: [
      {
        name: 'Standard ACH Transfer',
        description: 'Best for domestic ACH payments and direct deposits',
        bestFor: 'Payroll, vendor payments, recurring transfers',
        requiredFields: ['Account_Number', 'Recipient_Name', 'Routing_Code', 'Amount'],
        optionalFields: ['Contact_Email', 'Reference', 'Memo']
      },
      {
        name: 'Wire Transfer',
        description: 'Use for same-day domestic wire transfers',
        bestFor: 'Urgent payments, large transactions, real estate',
        requiredFields: ['Account_Number', 'Recipient_Name', 'Routing_Code', 'Amount', 'SWIFT_Code'],
        optionalFields: ['Contact_Email', 'Beneficiary_Address', 'Purpose_Code']
      },
      {
        name: 'International SWIFT',
        description: 'For cross-border payments and foreign currency',
        bestFor: 'Global payments, foreign vendors, multi-currency',
        requiredFields: ['Account_Number', 'Recipient_Name', 'IBAN', 'Amount', 'SWIFT_Code', 'Currency'],
        optionalFields: ['Contact_Email', 'Beneficiary_Address', 'Purpose_Code', 'Reference']
      }
    ]
  },
  {
    id: 'hr',
    name: 'Human Resources',
    icon: UserGroupIcon,
    description: 'Employee data and workforce management',
    templates: [
      {
        name: 'Employee Master Data',
        description: 'Standard format for employee data systems',
        bestFor: 'Payroll, HRIS, benefits administration',
        requiredFields: ['Employee_ID', 'Full_Name', 'Department', 'Salary'],
        optionalFields: ['Contact_Email', 'Phone', 'Notes']
      },
      {
        name: 'Payroll Import',
        description: 'Format for payroll processing systems',
        bestFor: 'Salary payments, wage calculations, tax reporting',
        requiredFields: ['Employee_ID', 'Full_Name', 'Gross_Pay', 'Net_Pay', 'Pay_Period'],
        optionalFields: ['Tax_Deductions', 'Benefits', 'Bonus', 'Commission']
      },
      {
        name: 'Time & Attendance',
        description: 'Track employee hours and attendance',
        bestFor: 'Time tracking, shift management, overtime calculation',
        requiredFields: ['Employee_ID', 'Date', 'Clock_In', 'Clock_Out', 'Hours_Worked'],
        optionalFields: ['Break_Minutes', 'Overtime_Hours', 'Notes']
      }
    ]
  },
  {
    id: 'logistics',
    name: 'Logistics & Supply Chain',
    icon: InboxIcon,
    description: 'Shipping, inventory, and fulfillment',
    templates: [
      {
        name: 'Shipment Orders',
        description: 'Format for shipping and tracking systems',
        bestFor: 'Order fulfillment, inventory management, shipping',
        requiredFields: ['Order_ID', 'Recipient_Name', 'Address', 'Package_Weight', 'Tracking_Code'],
        optionalFields: ['Contact_Email', 'Delivery_Instructions', 'Service_Level']
      },
      {
        name: 'Warehouse Inventory',
        description: 'Track stock levels and locations',
        bestFor: 'Inventory management, stock audits, warehouse operations',
        requiredFields: ['SKU', 'Product_Name', 'Quantity', 'Location', 'Unit_Cost'],
        optionalFields: ['Reorder_Point', 'Supplier', 'Category', 'Expiry_Date']
      },
      {
        name: 'Purchase Orders',
        description: 'Format for procurement and vendor orders',
        bestFor: 'Supplier orders, procurement, vendor management',
        requiredFields: ['PO_Number', 'Vendor_Name', 'Item_Description', 'Quantity', 'Unit_Price'],
        optionalFields: ['Delivery_Date', 'Payment_Terms', 'Notes']
      }
    ]
  },
  {
    id: 'ecommerce',
    name: 'E-commerce & Retail',
    icon: CartIcon,
    description: 'Online sales and customer orders',
    templates: [
      {
        name: 'Order Export',
        description: 'Standard format for online store integrations',
        bestFor: 'Marketplace exports, fulfillment, analytics',
        requiredFields: ['Order_ID', 'Customer_Name', 'SKU', 'Quantity', 'Total_Amount', 'Currency'],
        optionalFields: ['Contact_Email', 'Shipping_Address', 'Promo_Code', 'Notes']
      },
      {
        name: 'Product Catalog',
        description: 'Format for product listings and updates',
        bestFor: 'Product feeds, marketplace uploads, catalog management',
        requiredFields: ['Product_ID', 'Product_Name', 'Price', 'Category', 'Stock_Status'],
        optionalFields: ['Description', 'Image_URL', 'Brand', 'Weight']
      },
      {
        name: 'Customer Data',
        description: 'Customer information and contact details',
        bestFor: 'CRM imports, marketing campaigns, customer service',
        requiredFields: ['Customer_ID', 'Full_Name', 'Email', 'Phone'],
        optionalFields: ['Address', 'City', 'State', 'ZIP_Code', 'Country']
      }
    ]
  }
];

export function TemplateStep({ onNext, onBack, selectedTemplate, setSelectedTemplate }: TemplateStepProps) {
  const [activeTab, setActiveTab] = useState<'library' | 'upload'>('library');
  const [expandedTemplates, setExpandedTemplates] = useState<Set<string>>(new Set());
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set(['banking']));
  const [showBackConfirm, setShowBackConfirm] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleTemplateSelect = (template: BankTemplate) => {
    setSelectedTemplate(template);
  };


  const handleBackClick = () => {
    if (selectedTemplate) {
      setShowBackConfirm(true);
    } else {
      onBack();
    }
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  const toggleExpanded = (templateName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedTemplates(prev => {
      const newSet = new Set(prev);
      if (newSet.has(templateName)) {
        newSet.delete(templateName);
      } else {
        newSet.add(templateName);
      }
      return newSet;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    // Handle file drop logic here if needed
  };

  return (
    <>
      <Page maxWidth="4xl" className="pb-32">
        <PageHeader
          title="Select Output Template"
          description="Choose the format you want to transform your data into."
        />

        <Stack gap="lg">
          {/* Top Choice Tiles - Salt InteractableCardGroup Pattern */}
          <Section>
            <InteractableCardGroup
              value={activeTab}
              onChange={(_, value) => setActiveTab(value as 'library' | 'upload')}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
              aria-label="Template selection mode"
            >
              {/* Choose from Library - First Card (Default Selected) */}
              <InteractableCard value="library" style={{ position: 'relative' }}>
                <StackLayout gap={1}>
                  {/* Row 1: Icon + Title */}
                  <StackLayout align="center" direction="row" gap={1}>
                    <FolderClosedIcon 
                      size={1.25} 
                      aria-hidden="true"
                      style={{ color: 'var(--salt-content-primary-foreground)', flexShrink: 0 }} 
                    />
                    <H3 style={{ 
                      margin: 0, 
                      fontFamily: 'var(--salt-text-fontFamily)',
                      fontSize: '1rem',
                      fontWeight: 600,
                      lineHeight: '1.5',
                      paddingRight: '32px'
                    }}>
                      Choose from Library
                    </H3>
                  </StackLayout>
                  
                  {/* Row 2: Description */}
                  <Text style={{ 
                    margin: 0,
                    fontFamily: 'var(--salt-text-fontFamily)',
                    color: 'var(--salt-content-secondary-foreground)',
                    fontSize: '0.875rem',
                    lineHeight: '1.5'
                  }}>
                    Select from pre-built templates
                  </Text>
                </StackLayout>
              </InteractableCard>

              {/* Upload Custom Template - Second Card */}
              <InteractableCard value="upload" style={{ position: 'relative' }}>
                <StackLayout gap={1}>
                  {/* Row 1: Icon + Title */}
                  <StackLayout align="center" direction="row" gap={1}>
                    <UploadIcon 
                      size={1.25} 
                      aria-hidden="true"
                      style={{ color: 'var(--salt-content-primary-foreground)', flexShrink: 0 }} 
                    />
                    <H3 style={{ 
                      margin: 0, 
                      fontFamily: 'var(--salt-text-fontFamily)',
                      fontSize: '1rem',
                      fontWeight: 600,
                      lineHeight: '1.5',
                      paddingRight: '32px'
                    }}>
                      Upload Custom Template
                    </H3>
                  </StackLayout>
                  
                  {/* Row 2: Description */}
                  <Text style={{ 
                    margin: 0,
                    fontFamily: 'var(--salt-text-fontFamily)',
                    color: 'var(--salt-content-secondary-foreground)',
                    fontSize: '0.875rem',
                    lineHeight: '1.5'
                  }}>
                    Upload your own custom template file
                  </Text>
                </StackLayout>
              </InteractableCard>
            </InteractableCardGroup>
          </Section>

          {/* Content */}
          {activeTab === 'upload' ? (
            <Section>
              {/* Upload Custom Template Drop Zone - Salt Pattern */}
              <Card
                variant="primary"
                className="p-8 text-center"
                style={{
                  border: `2px dashed ${isDragOver ? 'var(--salt-color-accent-border)' : 'var(--salt-separable-borderColor)'}`,
                  backgroundColor: isDragOver ? 'var(--salt-color-accent-background)' : 'var(--salt-container-background)',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer',
                  outline: 'none',
                  borderStyle: 'dashed'
                }}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('template-file-input')?.click()}
                onFocus={(e) => {
                  e.currentTarget.style.outline = '2px solid var(--salt-color-accent-border)';
                  e.currentTarget.style.outlineOffset = '2px';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.outline = 'none';
                }}
                tabIndex={0}
                role="button"
                aria-label="Template file upload drop zone"
              >
                <div className="py-12">
                  <div
                    className="w-16 h-16 flex items-center justify-center mx-auto mb-4"
                    style={{
                      backgroundColor: 'var(--salt-color-gray-20)'
                    }}
                  >
                    <DocumentIcon size={2} style={{ color: 'var(--salt-content-secondary-foreground)' }} />
                  </div>
                  <H3 style={{ color: 'var(--salt-content-primary-foreground)', marginBottom: '0.5rem' }}>
                    Upload Custom Template
                  </H3>
                  <Text style={{ fontSize: 'var(--salt-text-fontSize)', color: 'var(--salt-content-secondary-foreground)', marginBottom: '1rem' }}>
                    Upload your own template file with your specific format
                  </Text>
                  <Button
                    variant="primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      document.getElementById('template-file-input')?.click();
                    }}
                  >
                    Browse Files
                  </Button>
                  <input
                    id="template-file-input"
                    type="file"
                    accept=".json,.csv"
                    className="hidden"
                  />
                </div>
              </Card>
            </Section>
          ) : (
            <Section>
              <Stack gap="md">
                {templateCategories.map((category) => {
                  const CategoryIcon = category.icon;
                  const isCategoryExpanded = expandedCategories.has(category.id);
                  const categoryTemplateCount = category.templates.length;

                  return (
                    <Collapsible key={category.id} open={isCategoryExpanded} onOpenChange={() => toggleCategory(category.id)}>
                      {/* Category Header - Salt Accordion Pattern */}
                      <CollapsibleTrigger asChild>
                        <Card
                          variant="primary"
                          hoverable
                          className="p-5 cursor-pointer"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div
                                className="w-12 h-12 flex items-center justify-center"
                                style={{
                                  backgroundColor: 'var(--salt-color-accent-background)'
                                }}
                              >
                                <CategoryIcon size={1.5} style={{ color: 'var(--salt-color-accent-foreground)' }} />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-1">
                                  <H3 style={{ color: 'var(--salt-content-primary-foreground)' }}>
                                    {category.name}
                                  </H3>
                                  <Text style={{ fontSize: 'var(--salt-text-fontSize-sm)', color: 'var(--salt-content-secondary-foreground)' }}>
                                    ({categoryTemplateCount} {categoryTemplateCount === 1 ? 'template' : 'templates'})
                                  </Text>
                                </div>
                                <Text style={{ fontSize: 'var(--salt-text-fontSize)', color: 'var(--salt-content-secondary-foreground)' }}>
                                  {category.description}
                                </Text>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <ChevronDownIcon
                                size={1.25}
                                style={{
                                  color: 'var(--salt-content-secondary-foreground)',
                                  transform: isCategoryExpanded ? 'rotate(0deg)' : 'rotate(-90deg)',
                                  transition: 'transform 200ms'
                                }}
                                aria-hidden="true"
                              />
                            </div>
                          </div>
                        </Card>
                      </CollapsibleTrigger>

                      {/* Category Templates */}
                      <CollapsibleContent>
                        <InteractableCardGroup
                          value={selectedTemplate?.name || ''}
                          onChange={(_, value) => {
                            const template = category.templates.find(t => t.name === value);
                            if (template) handleTemplateSelect(template);
                          }}
                          className="flex flex-col gap-3 mt-3 pl-6"
                          aria-label={`${category.name} templates`}
                          style={{ width: '100%' }}
                        >
                          {category.templates.map((template, index) => {
                            const isSelected = selectedTemplate?.name === template.name;
                            const isExpanded = expandedTemplates.has(template.name);

                            return (
                              <InteractableCard
                                key={index}
                                value={template.name}
                                style={{ width: '100%', position: 'relative' }}
                              >
                                <RadioIndicator selected={isSelected} />
                                <StackLayout gap={1}>
                                  {/* Row 1: Title */}
                                  <H3 style={{ 
                                    margin: 0,
                                    color: 'var(--salt-content-primary-foreground)', 
                                    fontFamily: 'var(--salt-text-fontFamily)',
                                    fontSize: '1rem',
                                    fontWeight: 600,
                                    paddingRight: '32px'
                                  }}>
                                    {template.name}
                                  </H3>
                                  
                                  {/* Row 2: Description */}
                                  <Text style={{ 
                                    margin: 0,
                                    color: 'var(--salt-content-secondary-foreground)',
                                    fontSize: '0.875rem',
                                    lineHeight: '1.5'
                                  }}>
                                    {template.description}
                                  </Text>

                                  {/* Best For */}
                                  <Text style={{ 
                                    fontSize: '0.8125rem', 
                                    color: 'var(--salt-content-secondary-foreground)',
                                    marginTop: '0.25rem'
                                  }}>
                                    <span style={{ fontWeight: 600 }}>Best for:</span> {template.bestFor}
                                  </Text>

                                  {/* Fields Section */}
                                  <div style={{ 
                                    marginTop: '1rem', 
                                    paddingTop: '1rem', 
                                    borderTop: '1px solid var(--salt-separable-borderColor)' 
                                  }}>
                                    {/* Required Fields */}
                                    <div style={{ marginBottom: '1rem' }}>
                                      <H4 style={{ 
                                        fontSize: '0.75rem', 
                                        color: 'var(--salt-content-secondary-foreground)', 
                                        textTransform: 'uppercase', 
                                        letterSpacing: '0.05em',
                                        marginBottom: '0.5rem'
                                      }}>
                                        Required Fields ({template.requiredFields.length})
                                      </H4>
                                      <div className="flex flex-wrap gap-2">
                                        {template.requiredFields.map((field) => (
                                          <Tag key={field} category={20}>{field}</Tag>
                                        ))}
                                      </div>
                                    </div>

                                    {/* Optional Fields */}
                                    {template.optionalFields.length > 0 && (
                                      <div>
                                        <div style={{ 
                                          display: 'flex', 
                                          alignItems: 'center', 
                                          gap: '0.5rem', 
                                          marginBottom: '0.5rem' 
                                        }}>
                                          <H4 style={{ 
                                            fontSize: '0.75rem', 
                                            color: 'var(--salt-content-secondary-foreground)', 
                                            textTransform: 'uppercase', 
                                            letterSpacing: '0.05em',
                                            margin: 0
                                          }}>
                                            Optional Fields ({template.optionalFields.length})
                                          </H4>
                                          {template.optionalFields.length > 3 && (
                                            <Button
                                              variant="ghost"
                                              size="small"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                toggleExpanded(template.name, e);
                                              }}
                                              style={{ marginLeft: 'auto' }}
                                            >
                                              {isExpanded ? 'Show less' : 'Show all'}
                                            </Button>
                                          )}
                                        </div>
                                        <div className="flex flex-wrap gap-2">
                                          {(isExpanded ? template.optionalFields : template.optionalFields.slice(0, 3)).map((field) => (
                                            <Tag key={field} category={15}>{field}</Tag>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </StackLayout>
                              </InteractableCard>
                            );
                          })}
                        </InteractableCardGroup>
                      </CollapsibleContent>
                    </Collapsible>
                  );
                })}
              </Stack>
            </Section>
          )}
        </Stack>
      </Page>

      {/* Action Bar - Salt Styled Footer */}
      <div
        className="fixed bottom-0 left-0 right-0 z-50"
        style={{
          backgroundColor: 'var(--salt-container-primary-background)',
          borderTop: '1px solid var(--salt-separable-primary-borderColor)',
          boxShadow: '0 -2px 8px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center gap-4">
            <Button
              variant="secondary"
              onClick={handleBackClick}
            >
              Back
            </Button>
            <Button
              variant="cta"
              onClick={onNext}
              disabled={!selectedTemplate}
            >
              Continue
            </Button>
          </div>
        </div>
      </div>

      {/* Back Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showBackConfirm}
        onOpenChange={setShowBackConfirm}
        onConfirm={onBack}
        title="Go back to upload?"
        description="Your template selection will be cleared if you go back. You'll need to select a template again."
        context="template selection"
      />
    </>
  );
}
