/**
 * Layout Components
 * 
 * Consistent application shell and page-level structure components.
 * These components use Salt Design System via src/ui/components wrappers
 * and Tailwind only for layout primitives.
 */

export { AppShell, type AppShellProps } from './AppShell';
export { TopNav, type TopNavProps, type TopNavAction } from './TopNav';
export { Page, type PageProps } from './Page';
export { PageHeader, type PageHeaderProps, type PageHeaderAction } from './PageHeader';
export { Section, type SectionProps } from './Section';
export { Stack, type StackProps } from './Stack';

