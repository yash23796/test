import React from 'react';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { Select, type SelectOption } from '../../components/Select';

export interface TableToolbarProps {
  /**
   * Search input value
   */
  searchValue?: string;
  /**
   * Search input onChange handler
   */
  onSearchChange?: (value: string) => void;
  /**
   * Search placeholder
   */
  searchPlaceholder?: string;
  /**
   * Filter options
   */
  filters?: {
    label: string;
    value: string;
    options: SelectOption[];
    onChange: (value: string) => void;
  }[];
  /**
   * Primary action button
   */
  primaryAction?: {
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
    disabled?: boolean;
    variant?: 'primary' | 'secondary' | 'cta';
  };
  /**
   * Secondary action buttons
   */
  secondaryActions?: Array<{
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
    disabled?: boolean;
    variant?: 'outline' | 'ghost';
  }>;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * TableToolbar - Consistent toolbar for table actions
 * Search, filters, and action buttons with consistent placement
 */
export const TableToolbar: React.FC<TableToolbarProps> = ({
  searchValue,
  onSearchChange,
  searchPlaceholder = 'Search...',
  filters = [],
  primaryAction,
  secondaryActions = [],
  className
}) => {
  return (
    <div className={`flex items-center justify-between gap-4 mb-4 ${className || ''}`}>
      <div className="flex items-center gap-3 flex-1">
        {onSearchChange && (
          <Input
            variant="primary"
            placeholder={searchPlaceholder}
            value={searchValue || ''}
            inputProps={{
              onChange: (e: React.ChangeEvent<HTMLInputElement>) => onSearchChange(e.target.value)
            }}
            className="max-w-xs"
          />
        )}
        {filters.map((filter, index) => (
          <Select
            key={index}
            variant="primary"
            placeholder={filter.label}
            value={filter.value}
            options={filter.options}
            onChange={filter.onChange}
          />
        ))}
      </div>
      
      <div className="flex items-center gap-2 flex-shrink-0">
        {secondaryActions.map((action, index) => (
          <Button
            key={index}
            variant={action.variant || 'outline'}
            onClick={action.onClick}
            disabled={action.disabled}
            icon={action.icon}
          >
            {action.label}
          </Button>
        ))}
        {primaryAction && (
          <Button
            variant={primaryAction.variant || 'primary'}
            onClick={primaryAction.onClick}
            disabled={primaryAction.disabled}
            icon={primaryAction.icon}
          >
            {primaryAction.label}
          </Button>
        )}
      </div>
    </div>
  );
};

