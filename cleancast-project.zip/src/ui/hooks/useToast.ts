import { toast } from 'sonner';

export type ToastSeverity = 'success' | 'error' | 'warning' | 'info';

/**
 * useToast - Unified toast API for consistent feedback
 * Uses sonner library (already in use) with Salt-aligned styling
 */
export const useToast = () => {
  const showToast = (
    message: string,
    severity: ToastSeverity = 'info',
    options?: {
      title?: string;
      duration?: number;
      action?: {
        label: string;
        onClick: () => void;
      };
    }
  ) => {
    const toastOptions = {
      duration: options?.duration || 5000,
    };

    switch (severity) {
      case 'success':
        toast.success(message, {
          ...toastOptions,
          description: options?.title,
        });
        break;
      case 'error':
        toast.error(message, {
          ...toastOptions,
          description: options?.title,
        });
        break;
      case 'warning':
        toast.warning(message, {
          ...toastOptions,
          description: options?.title,
        });
        break;
      case 'info':
      default:
        toast.info(message, {
          ...toastOptions,
          description: options?.title,
        });
        break;
    }
  };

  return {
    success: (message: string, options?: Parameters<typeof showToast>[2]) =>
      showToast(message, 'success', options),
    error: (message: string, options?: Parameters<typeof showToast>[2]) =>
      showToast(message, 'error', options),
    warning: (message: string, options?: Parameters<typeof showToast>[2]) =>
      showToast(message, 'warning', options),
    info: (message: string, options?: Parameters<typeof showToast>[2]) =>
      showToast(message, 'info', options),
  };
};

