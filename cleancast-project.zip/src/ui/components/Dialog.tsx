import React from 'react';
import { Dialog as SaltDialog, DialogHeader, DialogActions } from '@salt-ds/core';
import { Button } from './Button';

export interface DialogProps {
  /**
   * Whether dialog is open
   */
  open: boolean;
  /**
   * Callback when open state changes
   */
  onOpenChange: (open: boolean) => void;
  /**
   * Dialog title
   */
  title: string;
  /**
   * Dialog content/description
   */
  children: React.ReactNode;
  /**
   * Primary action button
   */
  primaryAction?: {
    label: string;
    onClick: () => void;
    variant?: 'primary' | 'secondary' | 'cta';
    disabled?: boolean;
  };
  /**
   * Secondary action button
   */
  secondaryAction?: {
    label: string;
    onClick: () => void;
    variant?: 'outline' | 'ghost';
    disabled?: boolean;
  };
  /**
   * Dialog status/variant
   */
  status?: 'error' | 'warning' | 'success' | 'info';
  /**
   * Dialog size
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
  /**
   * Prevent closing on click away
   * @default false
   */
  disableDismiss?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * Dialog component wrapper around Salt Design System Dialog
 * Provides a simplified API with consistent action button placement
 */
export const Dialog: React.FC<DialogProps> = ({
  open,
  onOpenChange,
  title,
  children,
  primaryAction,
  secondaryAction,
  status,
  size = 'medium',
  disableDismiss = false,
  className
}) => {
  const handleClose = () => {
    if (!disableDismiss) {
      onOpenChange(false);
    }
  };

  return (
    <SaltDialog
      open={open}
      onOpenChange={handleClose}
      status={status}
      size={size}
      className={className}
    >
      <DialogHeader
        header={title}
        description={children}
        status={status}
      />
      {(primaryAction || secondaryAction) && (
        <DialogActions>
          {secondaryAction && (
            <Button
              variant={secondaryAction.variant || 'outline'}
              onClick={secondaryAction.onClick}
              disabled={secondaryAction.disabled}
            >
              {secondaryAction.label}
            </Button>
          )}
          {primaryAction && (
            <Button
              variant={primaryAction.variant || 'primary'}
              onClick={primaryAction.onClick}
              disabled={primaryAction.disabled}
            >
              {primaryAction.label}
            </Button>
          )}
        </DialogActions>
      )}
    </SaltDialog>
  );
};

