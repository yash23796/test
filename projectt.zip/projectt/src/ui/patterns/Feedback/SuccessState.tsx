import React from 'react';
import { Card } from '../../components/Card';
import { Button } from '../../components/Button';
import { CheckCircle } from 'lucide-react';

export interface SuccessStateProps {
  /**
   * Success title
   */
  title: string;
  /**
   * Success message/description
   */
  message?: string;
  /**
   * Primary action button
   */
  primaryAction?: {
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
  };
  /**
   * Secondary action buttons
   */
  secondaryActions?: Array<{
    label: string;
    onClick: () => void;
    icon?: React.ReactNode;
  }>;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * SuccessState - Standardized success state display
 * Shows success message with next action options
 */
export const SuccessState: React.FC<SuccessStateProps> = ({
  title,
  message,
  primaryAction,
  secondaryActions = [],
  className
}) => {
  return (
    <Card variant="primary" className={`p-8 text-center ${className || ''}`}>
      <div className="flex flex-col items-center">
        <div className="mb-4" style={{ color: 'var(--salt-color-green-600)' }}>
          <CheckCircle className="w-12 h-12" />
        </div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        {message && (
          <p className="text-sm mb-6" style={{ color: 'var(--salt-color-gray-600)' }}>
            {message}
          </p>
        )}
        <div className="flex items-center gap-3">
          {secondaryActions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              onClick={action.onClick}
              icon={action.icon}
            >
              {action.label}
            </Button>
          ))}
          {primaryAction && (
            <Button
              variant="primary"
              onClick={primaryAction.onClick}
              icon={primaryAction.icon}
            >
              {primaryAction.label}
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};

