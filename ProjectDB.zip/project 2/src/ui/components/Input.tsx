import React from 'react';
import { Input as SaltInput, type InputProps as SaltInputProps } from '@salt-ds/core';

export interface InputProps extends Omit<SaltInputProps, 'variant'> {
  /**
   * Input variant
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary';
  /**
   * Input size
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
  /**
   * Icon to display at the start of the input
   */
  startIcon?: React.ReactNode;
  /**
   * Icon to display at the end of the input
   */
  endIcon?: React.ReactNode;
  /**
   * Validation status
   */
  validationStatus?: 'error' | 'warning' | 'success';
}

/**
 * Input component wrapper around Salt Design System Input
 * Provides a simplified API while using Salt components internally
 */
export const Input = React.forwardRef<HTMLDivElement, InputProps>(
  ({ variant = 'primary', size, startIcon, endIcon, validationStatus, className, ...props }, ref) => {
    const saltProps: SaltInputProps = {
      ...props,
      variant,
      validationStatus,
      className,
      startAdornment: startIcon,
      endAdornment: endIcon,
    };

    return <SaltInput {...saltProps} ref={ref} />;
  }
);

Input.displayName = 'Input';

