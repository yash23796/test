import { useState } from 'react';
import { Banner, Button as SaltButton, Card, Text, H3 } from '@salt-ds/core';
import { SaveIcon } from '@salt-ds/icons';
import { UploadedFile, BankTemplate, FieldMapping } from '../App';
import { StickyFooter } from './StickyFooter';
import { ConfirmDiscardDialog } from '../ui/patterns/Feedback';
import { ProgressSummary, EmptyState } from '../ui/patterns';
import { ColumnMappingCell } from '../ui/patterns/Table';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

interface MappingStepProps {
  onNext: () => void;
  onBack: () => void;
  uploadedFile: UploadedFile | null;
  selectedTemplate: BankTemplate | null;
  fieldMapping: FieldMapping;
  setFieldMapping: (mapping: FieldMapping) => void;
}

export function MappingStep({ 
  onNext, 
  onBack, 
  uploadedFile, 
  selectedTemplate, 
  fieldMapping, 
  setFieldMapping 
}: MappingStepProps) {
  const [autoMapped, setAutoMapped] = useState(false);
  const [showBackConfirm, setShowBackConfirm] = useState(false);
  const [mappingSaved, setMappingSaved] = useState(false);

  // Auto-mapping suggestions
  const getAutoMapping = () => {
    if (!uploadedFile || !selectedTemplate) return {};
    
    const suggestions: FieldMapping = {};
    const fileHeaders = uploadedFile.headers.map(h => h.toLowerCase());
    const allTemplateFields = [...selectedTemplate.requiredFields, ...selectedTemplate.optionalFields];
    
    // Smart mapping logic
    allTemplateFields.forEach(templateField => {
      const templateLower = templateField.toLowerCase();
      
      // Direct matches
      const directMatch = fileHeaders.find(header => 
        header.includes(templateLower.replace('_', '')) ||
        templateLower.replace('_', '').includes(header)
      );
      
      if (directMatch) {
        const originalHeader = uploadedFile.headers[fileHeaders.indexOf(directMatch)];
        suggestions[templateField] = originalHeader;
        return;
      }
      
      // Fuzzy matches
      if (templateLower.includes('acct') || templateLower.includes('account')) {
        const accountMatch = fileHeaders.find(h => h.includes('account') || h.includes('acct'));
        if (accountMatch) {
          suggestions[templateField] = uploadedFile.headers[fileHeaders.indexOf(accountMatch)];
        }
      }
      
      if (templateLower.includes('name') || templateLower.includes('recipient')) {
        const nameMatch = fileHeaders.find(h => h.includes('name') || h.includes('vendor'));
        if (nameMatch) {
          suggestions[templateField] = uploadedFile.headers[fileHeaders.indexOf(nameMatch)];
        }
      }
      
      if (templateLower.includes('routing')) {
        const routingMatch = fileHeaders.find(h => h.includes('routing') || h.includes('bank'));
        if (routingMatch) {
          suggestions[templateField] = uploadedFile.headers[fileHeaders.indexOf(routingMatch)];
        }
      }
      
      if (templateLower.includes('email')) {
        const emailMatch = fileHeaders.find(h => h.includes('email'));
        if (emailMatch) {
          suggestions[templateField] = uploadedFile.headers[fileHeaders.indexOf(emailMatch)];
        }
      }
    });
    
    return suggestions;
  };

  const handleAutoMap = () => {
    const autoMapping = getAutoMapping();
    setFieldMapping(autoMapping);
    setAutoMapped(true);
  };

  const handleFieldMapping = (templateField: string, fileHeader: string) => {
    setFieldMapping({
      ...fieldMapping,
      [templateField]: fileHeader
    });
    setMappingSaved(false);
  };

  const handleSaveMapping = () => {
    // In a real app, this would save to localStorage or backend
    setMappingSaved(true);
    setTimeout(() => {
      setMappingSaved(false);
    }, 3000);
  };

  const getMappedCount = () => {
    if (!selectedTemplate) return 0;
    return selectedTemplate.requiredFields.filter(field => fieldMapping[field]).length;
  };

  const getTotalRequired = () => {
    return selectedTemplate?.requiredFields.length || 0;
  };

  const canProceed = () => {
    if (!selectedTemplate) return false;
    return selectedTemplate.requiredFields.every(field => fieldMapping[field]);
  };

  const hasMappings = Object.keys(fieldMapping).length > 0;

  const handleBackClick = () => {
    if (hasMappings) {
      setShowBackConfirm(true);
    } else {
      onBack();
    }
  };

  if (!uploadedFile || !selectedTemplate) {
    return (
      <Page maxWidth="6xl" className="pb-32">
        <EmptyState
          title="Missing Data"
          description="Please upload a file and select a template to continue."
        />
      </Page>
    );
  }

  const mappedCount = getMappedCount();
  const totalRequired = getTotalRequired();
  const progressStatus = mappedCount === totalRequired ? 'success' : mappedCount > 0 ? 'warning' : 'error';

  return (
    <Page maxWidth="6xl" className="pb-32">
      <PageHeader
        title="Map Fields"
        description="Match your file columns to the output template fields. Required fields must be mapped to continue."
      />

      <Stack gap="lg">
        <ProgressSummary
          current={mappedCount}
          total={totalRequired}
          label="Required Fields Mapped"
          status={progressStatus}
        />

        {/* Auto-mapping suggestion */}
        {!autoMapped && (
          <Banner 
            status="info" 
            variant="secondary"
            style={{ marginBottom: '1rem' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', gap: '1rem' }}>
              <Text>
                We can automatically map common fields. You can adjust them afterwards.
              </Text>
              <SaltButton
                variant="secondary"
                onClick={handleAutoMap}
                disabled={autoMapped}
              >
                Auto-Map Fields
              </SaltButton>
            </div>
          </Banner>
        )}

        {/* Field Mapping Interface */}
        <Section title="Field Mapping">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', marginBottom: '2rem' }}>
            {/* Your File */}
            <Card style={{ 
              padding: '1.5rem', 
              borderRadius: '8px',
              boxShadow: 'var(--salt-overlayable-shadow-default)'
            }}>
              <H3 style={{ marginBottom: '1rem', color: 'var(--salt-content-primary-foreground)' }}>Your File</H3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {uploadedFile.headers.map((header, index) => (
                  <div 
                    key={index}
                    style={{
                      padding: '0.75rem',
                      backgroundColor: 'var(--salt-container-secondary-background)',
                      borderRadius: '4px',
                      border: '1px solid var(--salt-separable-primary-borderColor)',
                      color: 'var(--salt-content-primary-foreground)'
                    }}
                  >
                    {header}
                  </div>
                ))}
              </div>
            </Card>

            {/* Output Template */}
            <Card style={{ 
              padding: '1.5rem', 
              borderRadius: '8px',
              boxShadow: 'var(--salt-overlayable-shadow-default)'
            }}>
              <H3 style={{ marginBottom: '1rem', color: 'var(--salt-content-primary-foreground)' }}>Output Template</H3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {/* Required Fields */}
                {selectedTemplate.requiredFields.map((field) => {
                  const isMapped = !!fieldMapping[field];
                  return (
                    <Card 
                      key={field} 
                      style={{
                        padding: '1rem',
                        borderRadius: '4px',
                        border: isMapped 
                          ? '2px solid var(--salt-status-success-borderColor)' 
                          : '2px solid var(--salt-status-error-borderColor)',
                        backgroundColor: 'var(--salt-container-primary-background)'
                      }}
                    >
                      <div style={{ marginBottom: '0.75rem' }}>
                        <Text style={{ fontWeight: 600, color: 'var(--salt-content-primary-foreground)' }}>{field}</Text>
                      </div>
                      <ColumnMappingCell
                        value={fieldMapping[field] || ''}
                        options={uploadedFile.headers.map(header => ({ value: header, label: header }))}
                        onChange={(value) => handleFieldMapping(field, value)}
                        placeholder="Select field to map..."
                        validationStatus={isMapped ? 'success' : 'error'}
                        required={true}
                        errorText={!isMapped ? 'Required field' : undefined}
                        helperText={isMapped ? 'Mapped' : undefined}
                      />
                    </Card>
                  );
                })}

                {/* Optional Fields */}
                {selectedTemplate.optionalFields.map((field) => {
                  const isMapped = !!fieldMapping[field];
                  return (
                    <Card 
                      key={field} 
                      style={{
                        padding: '1rem',
                        borderRadius: '4px',
                        border: isMapped 
                          ? '2px solid var(--salt-status-success-borderColor)' 
                          : '1px solid var(--salt-separable-primary-borderColor)',
                        backgroundColor: 'var(--salt-container-primary-background)'
                      }}
                    >
                      <div style={{ marginBottom: '0.75rem' }}>
                        <Text style={{ fontWeight: 600, color: 'var(--salt-content-primary-foreground)' }}>{field}</Text>
                      </div>
                      <ColumnMappingCell
                        value={fieldMapping[field] || ''}
                        options={uploadedFile.headers.map(header => ({ value: header, label: header }))}
                        onChange={(value) => handleFieldMapping(field, value)}
                        placeholder="Select field to map..."
                        validationStatus={isMapped ? 'success' : undefined}
                        required={false}
                        helperText={isMapped ? 'Mapped' : 'Optional field'}
                      />
                    </Card>
                  );
                })}
              </div>
            </Card>
          </div>
        </Section>

        {/* Save Mapping Profile - Compact Card */}
        <Section>
          <Card variant="primary" style={{ 
            padding: '0.75rem 1rem', 
            borderRadius: '8px',
            boxShadow: 'var(--salt-overlayable-shadow-default)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <SaveIcon size={1} style={{ color: mappingSaved ? 'var(--salt-status-success-foreground)' : 'var(--salt-content-secondary-foreground)' }} />
                <Text style={{ fontSize: '0.875rem', fontWeight: 500 }}>
                  {mappingSaved ? 'Mapping saved' : 'Save this mapping configuration for future imports'}
                </Text>
              </div>
              <SaltButton 
                variant="secondary"
                onClick={handleSaveMapping}
                disabled={mappingSaved}
              >
                <SaveIcon size={0.75} style={{ marginRight: '0.25rem' }} />
                {mappingSaved ? 'Saved' : 'Save Profile'}
              </SaltButton>
            </div>
          </Card>
        </Section>
      </Stack>

      {/* Sticky Footer Navigation */}
      <StickyFooter
        onBack={handleBackClick}
        onNext={onNext}
        nextDisabled={!canProceed()}
      />

      {/* Back Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showBackConfirm}
        onOpenChange={setShowBackConfirm}
        onConfirm={onBack}
        title="Go back to template selection?"
        description="Your field mappings will be lost if you go back. You'll need to map fields again."
        context="field mappings"
      />
    </Page>
  );
}