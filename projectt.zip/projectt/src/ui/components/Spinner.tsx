import React from 'react';
import { Spinner as SaltSpinner } from '@salt-ds/core';

export interface SpinnerProps {
  /**
   * Spinner size
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large' | 'default';
  /**
   * Additional className
   */
  className?: string;
  /**
   * Aria label for accessibility
   */
  'aria-label'?: string;
}

/**
 * Spinner component wrapper around Salt Design System Spinner
 * Simple loading indicator with consistent sizing
 */
export const Spinner: React.FC<SpinnerProps> = ({
  size = 'medium',
  className,
  'aria-label': ariaLabel = 'Loading...'
}) => {
  return (
    <SaltSpinner
      size={size}
      className={className}
      aria-label={ariaLabel}
    />
  );
};

