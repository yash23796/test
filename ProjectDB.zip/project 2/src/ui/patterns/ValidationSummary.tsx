import React from 'react';
import { Banner, Button as SaltButton, Card, Text } from '@salt-ds/core';
import { SuccessTickIcon, ErrorSolidIcon, EditIcon, RefreshIcon } from '@salt-ds/icons';
import { Badge } from '../components/Badge';
import { DataTable, RowActions } from './Table';

export interface ValidationError {
  row: number;
  field?: string;
  error: string;
  value?: string | number;
}

export interface ValidationSummaryProps {
  /**
   * Number of valid rows
   */
  valid: number;
  /**
   * Total number of rows
   */
  total: number;
  /**
   * Number of errors
   */
  errors: number;
  /**
   * Error details (optional, for display)
   */
  errorDetails?: ValidationError[];
  /**
   * Show error details section
   * @default false
   */
  showErrorDetails?: boolean;
  /**
   * Callback for re-validate action
   */
  onRevalidate?: () => void;
  /**
   * Callback for edit all action
   */
  onEditAll?: () => void;
  /**
   * Callback for editing a single row
   */
  onEditRow?: (rowIndex: number) => void;
  /**
   * Is validating state
   * @default false
   */
  isValidating?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * ValidationSummary - Displays validation results with summary and error details
 * Uses Salt components for consistent styling
 */
export const ValidationSummary: React.FC<ValidationSummaryProps> = ({
  valid,
  total,
  errors,
  errorDetails = [],
  showErrorDetails = false,
  onRevalidate,
  onEditAll,
  onEditRow,
  isValidating = false,
  className
}) => {
  const hasErrors = errors > 0;

  return (
    <div className={className || ''}>
      {/* Summary Banner */}
      <div className="sticky top-0 z-10 mb-6">
        <Banner 
          status={hasErrors ? 'error' : 'success'}
          variant="secondary"
          style={{ 
            borderRadius: '8px'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <Text style={{ fontWeight: 600 }}>
                {valid} of {total} rows valid
              </Text>
              {hasErrors && (
                <Text style={{ display: 'block', marginTop: '0.25rem' }}>
                  {errors} errors must be fixed before export
                </Text>
              )}
            </div>
            {onRevalidate && (
              <SaltButton 
                variant="secondary"
                onClick={onRevalidate}
                disabled={isValidating}
              >
                {isValidating ? <RefreshIcon size={1} style={{ animation: 'spin 1s linear infinite' }} /> : null}
                Re-validate
              </SaltButton>
            )}
          </div>
        </Banner>
      </div>

      {/* Error Details Section */}
      {showErrorDetails && hasErrors && errorDetails.length > 0 && (
        <Card variant="primary" style={{ padding: '1.5rem', marginBottom: '1.5rem', borderRadius: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <Text style={{ fontWeight: 600 }}>Error Details</Text>
              <Badge value={`${errors} errors found`} />
            </div>
            {onEditAll && (
              <SaltButton variant="secondary" onClick={onEditAll}>
                <EditIcon size={1} style={{ marginRight: '0.5rem' }} />
                Edit All Data
              </SaltButton>
            )}
          </div>
          
          <DataTable
            columns={[
              {
                header: 'Row',
                accessor: 'row',
                noWrap: true,
                width: '80px'
              },
              {
                header: 'Error',
                accessor: (error) => (
                  <div>
                    <Text style={{ fontSize: '0.875rem' }}>
                      {error.error}
                      {error.value !== undefined && error.value !== null && (
                        <span style={{ marginLeft: '0.5rem', fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)' }}>
                          | Value: <span style={{ fontFamily: 'monospace' }}>"{String(error.value)}"</span>
                        </span>
                      )}
                    </Text>
                  </div>
                ),
                noWrap: false
              },
              {
                header: 'Actions',
                accessor: (error) => onEditRow ? (
                  <RowActions
                    actions={[{
                      label: 'Fix',
                      onClick: () => onEditRow(error.row - 1),
                      icon: <EditIcon size={0.75} />
                    }]}
                  />
                ) : null,
                noWrap: true,
                width: '100px'
              }
            ]}
            data={errorDetails.slice(0, 20)}
            getRowKey={(error, index) => `error-${error.row}-${index}`}
            emptyState={{
              title: 'No errors found',
              description: 'All rows are valid'
            }}
          />
          
          {errorDetails.length > 20 && (
            <div style={{ 
              padding: '1rem',
              borderRadius: '4px',
              border: '1px solid var(--salt-separable-primary-borderColor)',
              backgroundColor: 'var(--salt-container-secondary-background)',
              marginTop: '1rem'
            }}>
              <Text style={{ fontSize: '0.875rem' }}>
                Showing first 20 of {errorDetails.length} total errors.
                {onEditAll && (
                  <SaltButton 
                    variant="secondary"
                    onClick={onEditAll}
                    style={{ marginLeft: '0.5rem', padding: 0, height: 'auto' }}
                  >
                    View all in editor
                  </SaltButton>
                )}
              </Text>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

