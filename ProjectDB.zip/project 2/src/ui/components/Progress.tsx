import React from 'react';
import { LinearProgress, CircularProgress } from '@salt-ds/core';

export interface ProgressProps {
  /**
   * Progress value (0-100)
   * If undefined, shows indeterminate progress
   */
  value?: number;
  /**
   * Minimum value
   * @default 0
   */
  min?: number;
  /**
   * Maximum value
   * @default 100
   */
  max?: number;
  /**
   * Progress variant
   * @default 'linear'
   */
  variant?: 'linear' | 'circular';
  /**
   * Hide label
   * @default false
   */
  hideLabel?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * Progress component wrapper around Salt Design System Progress
 * Supports both linear and circular progress indicators
 */
export const Progress: React.FC<ProgressProps> = ({
  value,
  min = 0,
  max = 100,
  variant = 'linear',
  hideLabel = false,
  className
}) => {
  if (variant === 'circular') {
    return (
      <CircularProgress
        value={value}
        min={min}
        max={max}
        hideLabel={hideLabel}
        className={className}
      />
    );
  }

  return (
    <LinearProgress
      value={value}
      min={min}
      max={max}
      hideLabel={hideLabel}
      className={className}
    />
  );
};

