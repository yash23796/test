import { useCallback, useState } from 'react';
import { Eye, EyeOff, AlertCircle } from 'lucide-react';
import { Text, H3, H4, FileDropZone, Button as SaltButton, Spinner, Tag } from '@salt-ds/core';
import { SuccessTickIcon, ErrorSolidIcon, RefreshIcon, CloseIcon } from '@salt-ds/icons';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, ClientSideRowModelModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { Button, Card } from '../ui';

// Register AG Grid modules
ModuleRegistry.registerModules([ClientSideRowModelModule]);
import { UploadedFile } from '../App';
import { parseFile } from '../utils/fileParser';
import { useToast } from '../ui/hooks/useToast';
import { ConfirmDiscardDialog } from '../ui/patterns/Feedback';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

type FileStatus = 'uploading' | 'success' | 'error';

interface FileWithStatus {
  file: UploadedFile;
  status: FileStatus;
  error?: string;
  progress?: number;
}

interface UploadStepProps {
  onNext: () => void;
  onBack: () => void;
  uploadedFile: UploadedFile | null;
  setUploadedFile: (file: UploadedFile | null) => void;
}

export function UploadStep({ onNext, onBack, uploadedFile, setUploadedFile }: UploadStepProps) {
  const [fileWithStatus, setFileWithStatus] = useState<FileWithStatus | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showBackConfirm, setShowBackConfirm] = useState(false);
  const toast = useToast();

  const handleFileDrop = useCallback((_event: React.DragEvent<HTMLDivElement>, files: File[]) => {
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const handleFileUpload = async (file: File) => {
    // Create initial file entry with uploading status
    const tempFile: UploadedFile = {
      name: file.name,
      headers: [],
      data: []
    };
    
    setFileWithStatus({
      file: tempFile,
      status: 'uploading',
      progress: 0
    });
    
    try {
      // Validate file size (max 10MB)
      const maxSize = 10 * 1024 * 1024; // 10MB
      if (file.size > maxSize) {
        throw new Error('File size exceeds 10MB limit. Please upload a smaller file.');
      }

      // Validate file type
      const validExtensions = ['csv', 'xlsx', 'xls'];
      const extension = file.name.split('.').pop()?.toLowerCase();
      if (!extension || !validExtensions.includes(extension)) {
        throw new Error('Invalid file type. Please upload a CSV or Excel file.');
      }

      // Simulate progress for better UX with delays
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFileWithStatus(prev => prev ? { ...prev, progress: 20 } : null);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFileWithStatus(prev => prev ? { ...prev, progress: 40 } : null);
      
      // Parse the file using our utility
      const parsedData = await parseFile(file);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFileWithStatus(prev => prev ? { ...prev, progress: 60 } : null);
      
      // Validate parsed data
      if (parsedData.rowCount === 0) {
        throw new Error('File is empty. Please upload a file with data.');
      }

      if (parsedData.columnCount === 0) {
        throw new Error('No columns found in file. Please check your file format.');
      }

      await new Promise(resolve => setTimeout(resolve, 1000));
      setFileWithStatus(prev => prev ? { ...prev, progress: 80 } : null);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFileWithStatus(prev => prev ? { ...prev, progress: 100 } : null);

      // Set the uploaded file data
      const uploadedFileData: UploadedFile = {
        name: file.name,
        headers: parsedData.headers,
        data: parsedData.data
      };
      
      setUploadedFile(uploadedFileData);
      setFileWithStatus({
        file: uploadedFileData,
        status: 'success',
        progress: 100
      });
      setShowPreview(true);
      toast.success(`Successfully parsed ${parsedData.rowCount} rows and ${parsedData.columnCount} columns!`);
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to parse file';
      setFileWithStatus({
        file: tempFile,
        status: 'error',
        error: errorMessage
      });
      toast.error(errorMessage);
      setUploadedFile(null);
    }
  };

  const handleRetryUpload = () => {
    document.getElementById('file-input')?.click();
  };

  const handleRemoveFile = () => {
    setFileWithStatus(null);
    setUploadedFile(null);
    setShowPreview(false);
    
    // Reset the file input to allow re-uploading the same or different file
    const fileInput = document.getElementById('file-input') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  };

  return (
    <>
      <Page maxWidth="4xl" className="pb-32">
        <PageHeader
          title="Upload Your Data"
          description="Upload your CSV or Excel file containing the data you want to transform."
        />

        <Stack gap="lg">
          {/* Upload Area - Salt FileDropZone Component */}
          <Section>
            <Stack gap="lg">
              {/* File Drop Zone - Always Visible with Status Colors */}
              <FileDropZone 
                onDrop={handleFileDrop}
                status={
                  fileWithStatus?.status === 'success' ? 'success' :
                  fileWithStatus?.status === 'error' ? 'error' :
                  undefined
                }
              >
                <div style={{ padding: '2rem', textAlign: 'center' }}>
                  <H3 style={{ color: 'var(--salt-content-primary-foreground)', marginBottom: '0.5rem' }}>
                    Drag and drop your file here
                  </H3>
                  <Text style={{ color: 'var(--salt-content-secondary-foreground)', display: 'block', marginBottom: '1rem' }}>
                    or use the button below
                  </Text>
                  <div className="flex items-center gap-2 justify-center" style={{ marginBottom: '1rem' }}>
                    <Tag category={15}>CSV</Tag>
                    <Tag category={15}>Excel</Tag>
                    <Tag category={15}>XLSX</Tag>
                  </div>
            <SaltButton
              variant="primary"
              onClick={(e) => {
                e.stopPropagation();
                document.getElementById('file-input')?.click();
              }}
            >
              Choose File
            </SaltButton>
                  <Text style={{ color: 'var(--salt-content-secondary-foreground)', fontSize: 'var(--salt-text-fontSize-small)', display: 'block', marginTop: '1rem' }}>
                    Maximum file size: 10MB
                  </Text>
                </div>
              </FileDropZone>

              {/* Uploaded File List with Status - Salt Pattern */}
              {fileWithStatus && (
                <div style={{ 
                  borderTop: '1px solid var(--salt-separable-primary-borderColor)',
                  paddingTop: '1rem'
                }}>
                  <div 
                    style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '12px',
                      padding: '8px 0'
                    }}
                  >
                    {/* Status Icon - Salt Icons */}
                    {fileWithStatus.status === 'uploading' && (
                      <Spinner 
                        aria-label="Uploading" 
                        size="small"
                        style={{ 
                          color: 'var(--salt-status-info-foreground)',
                          flexShrink: 0
                        }}
                      />
                    )}
                    {fileWithStatus.status === 'success' && (
                      <SuccessTickIcon 
                        size={1}
                        style={{ 
                          color: 'var(--salt-status-success-foreground)',
                          flexShrink: 0
                        }} 
                      />
                    )}
                    {fileWithStatus.status === 'error' && (
                      <ErrorSolidIcon 
                        size={1}
                        style={{ 
                          color: 'var(--salt-status-error-foreground)',
                          flexShrink: 0
                        }} 
                      />
                    )}

                    {/* File Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <Text 
                        style={{ 
                          fontWeight: 600,
                          display: 'block',
                          marginBottom: '4px'
                        }}
                      >
                        {fileWithStatus.file.name}
                      </Text>
                      <Text 
                        style={{ 
                          fontSize: 'var(--salt-text-fontSize-small)', 
                          color: fileWithStatus.status === 'error' 
                            ? 'var(--salt-status-error-foreground)' 
                            : 'var(--salt-content-secondary-foreground)',
                          display: 'block'
                        }}
                      >
                        {fileWithStatus.status === 'uploading' && `Uploading... ${fileWithStatus.progress}%`}
                        {fileWithStatus.status === 'success' && `${fileWithStatus.file.data.length} rows • ${fileWithStatus.file.headers.length} columns`}
                        {fileWithStatus.status === 'error' && fileWithStatus.error}
                      </Text>
                    </div>

                    {/* Action Buttons */}
                    <div style={{ display: 'flex', gap: '8px', flexShrink: 0 }}>
                      {fileWithStatus.status === 'error' && (
                        <SaltButton
                          variant="secondary"
                          onClick={handleRetryUpload}
                          aria-label="Retry upload"
                        >
                          <RefreshIcon size={1} />
                        </SaltButton>
                      )}
                      {fileWithStatus.status !== 'uploading' && (
                        <SaltButton
                          variant="secondary"
                          onClick={handleRemoveFile}
                          aria-label="Remove file"
                        >
                          <CloseIcon size={1} />
                        </SaltButton>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <input
                id="file-input"
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileSelect}
                style={{ display: 'none' }}
              />
            </Stack>
          </Section>

          {/* Data Preview with AG Grid */}
          {uploadedFile && (
            <Section>
              {/* Separator */}
              <div 
                style={{ 
                  borderTop: '1px solid var(--salt-separable-primary-borderColor)', 
                  marginBottom: '1rem' 
                }} 
              />
              
              {/* Accordion Header - Data Preview */}
              <div 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'space-between',
                  marginBottom: '1rem',
                  cursor: 'pointer',
                  padding: '0.5rem 0'
                }}
                onClick={() => setShowPreview(!showPreview)}
              >
                <H3 style={{ margin: 0 }}>Data Preview</H3>
                <SaltButton 
                  variant="secondary"
                  sentiment="neutral"
                >
                  {showPreview ? (
                    <>
                      <EyeOff style={{ width: '16px', height: '16px', marginRight: '8px' }} />
                      Hide Preview
                    </>
                  ) : (
                    <>
                      <Eye style={{ width: '16px', height: '16px', marginRight: '8px' }} />
                      Show Preview
                    </>
                  )}
                </SaltButton>
              </div>
              {/* Accordion Content */}
              <div
                style={{
                  maxHeight: showPreview ? '1000px' : '0',
                  opacity: showPreview ? 1 : 0,
                  overflow: 'hidden',
                  transition: 'max-height 0.3s ease-in-out, opacity 0.3s ease-in-out'
                }}
              >
                <div style={{ paddingBottom: showPreview ? '1rem' : '0', transition: 'padding 0.3s ease-in-out' }}>
                  {/* Subheading - Only visible when open */}
                  {showPreview && (
                    <H4 style={{ marginBottom: '0.75rem' }}>First 5 rows of your data</H4>
                  )}
                  <div 
                    className="ag-theme-alpine" 
                    style={{ 
                      width: '100%',
                      '--ag-background-color': 'var(--salt-container-primary-background)',
                      '--ag-header-background-color': 'var(--salt-container-secondary-background)',
                      '--ag-odd-row-background-color': 'var(--salt-container-primary-background)',
                      '--ag-even-row-background-color': 'var(--salt-container-secondary-background)',
                      '--ag-header-foreground-color': 'var(--salt-content-primary-foreground)',
                      '--ag-foreground-color': 'var(--salt-content-primary-foreground)',
                      '--ag-border-color': 'var(--salt-separable-primary-borderColor)',
                      '--ag-row-border-color': 'var(--salt-separable-secondary-borderColor)',
                      '--ag-font-size': '12px',
                      '--ag-row-height': '32px',
                      '--ag-header-height': '36px',
                      '--ag-cell-horizontal-padding': '8px',
                      '--ag-header-column-separator-display': 'block',
                      '--ag-header-column-separator-color': 'var(--salt-separable-secondary-borderColor)',
                      borderRadius: 'var(--salt-size-border-radius)',
                      overflow: 'hidden',
                      boxShadow: 'var(--salt-shadow-1)'
                    } as React.CSSProperties
                  }>
                    <AgGridReact
                      rowData={uploadedFile.data.slice(0, 5)}
                      columnDefs={uploadedFile.headers.map(header => ({
                        field: header,
                        headerName: header,
                        sortable: true,
                        filter: true,
                        resizable: true,
                        flex: 1,
                        minWidth: 120,
                        wrapText: false,
                        autoHeight: false,
                        cellStyle: {
                          fontSize: '12px',
                          lineHeight: '32px',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }
                      }))}
                      defaultColDef={{
                        sortable: true,
                        filter: true,
                        resizable: true,
                        wrapText: false,
                        autoHeight: false
                      }}
                      domLayout="autoHeight"
                      suppressCellFocus={true}
                      rowHeight={32}
                      headerHeight={36}
                      enableCellTextSelection={true}
                      ensureDomOrder={true}
                    />
                  </div>
                  {uploadedFile.data.length > 5 && (
                    <Text 
                      style={{ 
                        display: 'block',
                        marginTop: '0.5rem',
                        padding: '0.5rem 0.75rem',
                        backgroundColor: 'var(--salt-container-secondary-background)',
                        borderRadius: 'var(--salt-size-border-radius)',
                        fontSize: 'var(--salt-text-fontSize-small)',
                        color: 'var(--salt-content-secondary-foreground)',
                        textAlign: 'center'
                      }}
                    >
                      ... and {uploadedFile.data.length - 5} more rows
                    </Text>
                  )}
                </div>
              </div>
            </Section>
          )}

          {/* Security & Features Info */}
          <Section title="Security & Features">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card variant="primary" className="p-6">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" style={{ color: 'var(--salt-color-success-foreground)' }}>
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                  <div>
                    <H4 style={{ color: 'var(--salt-content-primary-foreground)', marginBottom: '0.25rem' }}>
                      100% Secure
                    </H4>
                    <Text style={{ fontSize: 'var(--salt-text-fontSize)', color: 'var(--salt-content-secondary-foreground)' }}>
                      Your data is processed entirely in your browser. We never upload or store your sensitive information on any server.
                    </Text>
                  </div>
                </div>
              </Card>
              
              <Card variant="primary" className="p-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--salt-color-accent-foreground)' }} />
                  <div>
                    <H4 style={{ color: 'var(--salt-content-primary-foreground)', marginBottom: '0.25rem' }}>
                      Coming Soon
                    </H4>
                    <Text style={{ fontSize: 'var(--salt-text-fontSize)', color: 'var(--salt-content-secondary-foreground)' }}>
                      Direct connections to QuickBooks, NetSuite, and other accounting systems.
                    </Text>
                  </div>
                </div>
              </Card>
            </div>
          </Section>
        </Stack>
      </Page>

      {/* Action Bar - Salt Styled Footer */}
      <div 
        className="fixed bottom-0 left-0 right-0 z-50"
        style={{
          backgroundColor: 'var(--salt-container-primary-background)',
          borderTop: '1px solid var(--salt-separable-primary-borderColor)',
          boxShadow: '0 -2px 8px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center gap-4">
            <Button
              variant="secondary"
              onClick={() => uploadedFile ? setShowBackConfirm(true) : onBack()}
            >
              Back
            </Button>
            <Button
              variant="cta"
              onClick={onNext}
              disabled={!uploadedFile}
            >
              Continue
            </Button>
          </div>
        </div>
      </div>

      {/* Back Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showBackConfirm}
        onOpenChange={setShowBackConfirm}
        onConfirm={onBack}
        title="Go back to dashboard?"
        description="Your uploaded file will be cleared if you go back. You'll need to upload again."
        context="uploaded file"
      />
    </>
  );
}