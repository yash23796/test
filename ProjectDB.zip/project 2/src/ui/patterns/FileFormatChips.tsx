import React from 'react';
import { Badge } from '../components/Badge';

export interface FileFormatChipsProps {
  /**
   * Formats to display
   * @default ['CSV', 'Excel', 'XLSX']
   */
  formats?: string[];
  /**
   * Additional className
   */
  className?: string;
}

/**
 * FileFormatChips - Displays file format badges/chips
 * Uses Salt Badge component for consistent styling
 */
export const FileFormatChips: React.FC<FileFormatChipsProps> = ({ 
  formats = ['CSV', 'Excel', 'XLSX'],
  className 
}) => {
  return (
    <div className={`flex items-center gap-2 ${className || ''}`}>
      {formats.map((format) => (
        <Badge key={format} value={format} />
      ))}
    </div>
  );
};

