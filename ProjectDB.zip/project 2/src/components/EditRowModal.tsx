/**
 * Modal for editing a single row of data
 * Shows only the fields that need editing with error highlighting
 */

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogActions, Button, FormField, FormFieldLabel, FormFieldHelperText, Input } from '@salt-ds/core';
import { SaveIcon } from '@salt-ds/icons';
import { BankTemplate, FieldMapping } from '../App';
import { ValidationError, validateFieldFormat } from '../utils/dataValidation';

interface EditRowModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowIndex: number;
  rowData: Record<string, any>;
  fieldMapping: FieldMapping;
  template: BankTemplate;
  errors: ValidationError[];
  onSave: (rowIndex: number, updatedData: Record<string, any>) => void;
}

export function EditRowModal({
  isOpen,
  onClose,
  rowIndex,
  rowData,
  fieldMapping,
  template,
  errors: _errors,
  onSave,
}: EditRowModalProps) {
  const [editedData, setEditedData] = useState<Record<string, any>>({ ...rowData });
  const [currentErrors, setCurrentErrors] = useState<Map<string, string>>(new Map());

  // Get all fields to display
  const allFields = [...template.requiredFields, ...template.optionalFields];

  // Reset edited data and validate when modal opens
  useEffect(() => {
    if (isOpen) {
      setEditedData({ ...rowData });
      
      // Re-validate all fields when modal opens
      const errorMap = new Map<string, string>();
      const fields = [...template.requiredFields, ...template.optionalFields];
      
      fields.forEach((targetField) => {
        const sourceField = fieldMapping[targetField];
        if (sourceField) {
          const value = rowData[sourceField];
          const isRequired = template.requiredFields.includes(targetField);
          const trimmedValue = value ? String(value).trim() : '';

          if (isRequired && trimmedValue === '') {
            errorMap.set(targetField, 'Required field is empty');
          } else if (trimmedValue !== '') {
            const formatError = validateFieldFormat(targetField, value);
            if (formatError) {
              errorMap.set(targetField, formatError);
            }
          }
        }
      });
      setCurrentErrors(errorMap);
    }
  }, [isOpen, rowIndex]); // Only depend on isOpen and rowIndex

  if (!isOpen) return null;

  const hasErrors = currentErrors.size > 0;

  const handleSave = () => {
    if (hasErrors) return; // Don't save if there are errors
    onSave(rowIndex, editedData);
    onClose();
  };

  const handleFieldChange = (targetField: string, value: string) => {
    const sourceField = fieldMapping[targetField];
    if (sourceField) {
      // Update the data
      setEditedData((prev) => ({
        ...prev,
        [sourceField]: value,
      }));

      // Validate the field in real-time
      const isRequired = template.requiredFields.includes(targetField);
      const trimmedValue = value.trim();

      setCurrentErrors((prev) => {
        const newErrors = new Map(prev);

        // Check if required field is empty
        if (isRequired && trimmedValue === '') {
          newErrors.set(targetField, 'Required field is empty');
        } else if (trimmedValue !== '') {
          // Validate format if not empty
          const formatError = validateFieldFormat(targetField, value);
          if (formatError) {
            newErrors.set(targetField, formatError);
          } else {
            // Clear error if validation passes
            newErrors.delete(targetField);
          }
        } else {
          // Clear error for optional empty fields
          newErrors.delete(targetField);
        }

        return newErrors;
      });
    }
  };

  const getFieldValue = (targetField: string): string => {
    const sourceField = fieldMapping[targetField];
    if (sourceField) {
      return editedData[sourceField] || '';
    }
    return '';
  };

  const getFieldError = (targetField: string): string | null => {
    return currentErrors.get(targetField) || null;
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()} size="large">
      <DialogContent style={{ maxHeight: '90vh', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DialogHeader
          header="Edit Row Data"
          description="Review and update the field values for this record."
        />

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '1.5rem 2rem' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {allFields.map((targetField) => {
              const sourceField = fieldMapping[targetField];
              if (!sourceField) return null;

              const hasError = currentErrors.has(targetField);
              const error = getFieldError(targetField);
              const value = getFieldValue(targetField);
              const isRequired = template.requiredFields.includes(targetField);

              return (
                <FormField
                  key={targetField}
                  labelPlacement="top"
                  validationStatus={hasError ? 'error' : undefined}
                  style={{ width: '100%' }}
                >
                  <FormFieldLabel>
                    {targetField.replace(/_/g, ' ')}
                    {isRequired && ' *'}
                  </FormFieldLabel>
                  <Input
                    value={value}
                    onChange={(e) => handleFieldChange(targetField, e.target.value)}
                    variant="primary"
                    style={{ width: '100%' }}
                  />
                  {hasError && error && (
                    <FormFieldHelperText>
                      {error}
                    </FormFieldHelperText>
                  )}
                  {!hasError && value && (
                    <FormFieldHelperText>
                      Mapped from: {sourceField}
                    </FormFieldHelperText>
                  )}
                </FormField>
              );
            })}
          </div>
        </div>

        <DialogActions>
          <Button onClick={onClose} variant="secondary">
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={hasErrors}
            variant="cta"
          >
            <SaveIcon size={1} style={{ marginRight: '0.5rem' }} />
            Save Changes
          </Button>
        </DialogActions>
      </DialogContent>
    </Dialog>
  );
}
