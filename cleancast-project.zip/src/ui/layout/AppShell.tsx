import React from 'react';
import { TopNav, TopNavProps } from './TopNav';

export interface AppShellProps {
  /**
   * App content
   */
  children: React.ReactNode;
  /**
   * Top navigation props
   */
  topNav?: TopNavProps;
  /**
   * Show top navigation
   * @default true
   */
  showTopNav?: boolean;
  /**
   * Additional className for shell
   */
  className?: string;
}

/**
 * AppShell - Overall layout wrapper for the application
 * Provides consistent structure: top nav + content area
 */
export const AppShell: React.FC<AppShellProps> = ({
  children,
  topNav,
  showTopNav = true,
  className = ''
}) => {
  return (
    <div className={`min-h-screen flex flex-col ${className}`} style={{ backgroundColor: 'var(--salt-color-white)' }}>
      {showTopNav && <TopNav {...topNav} />}
      <main className="flex-1" role="main">
        {children}
      </main>
    </div>
  );
};

