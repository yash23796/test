import React from 'react';
import { Button } from '../../components/Button';

export interface RowAction {
  /**
   * Action label
   */
  label: string;
  /**
   * Action onClick handler
   */
  onClick: () => void;
  /**
   * Action icon
   */
  icon?: React.ReactNode;
  /**
   * Whether action is disabled
   * @default false
   */
  disabled?: boolean;
  /**
   * Action variant (for destructive actions)
   */
  variant?: 'default' | 'destructive';
}

export interface RowActionsProps {
  /**
   * Available actions
   */
  actions: RowAction[];
  /**
   * Show as dropdown menu (future enhancement)
   * @default false
   */
  asMenu?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * RowActions - Consistent row action buttons
 * Can be displayed inline or as a menu (menu implementation can be added later)
 */
export const RowActions: React.FC<RowActionsProps> = ({
  actions,
  className
}) => {
  if (actions.length === 0) {
    return null;
  }

  // For now, render inline buttons
  // Menu implementation can be added later using Salt Dropdown
  return (
    <div className={`flex items-center gap-2 ${className || ''}`}>
      {actions.map((action, index) => (
        <Button
          key={index}
          variant={action.variant === 'destructive' ? 'outline' : 'ghost'}
          onClick={action.onClick}
          disabled={action.disabled}
          icon={action.icon}
        >
          {action.label}
        </Button>
      ))}
    </div>
  );
};

