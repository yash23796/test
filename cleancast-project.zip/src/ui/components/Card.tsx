import React from 'react';
import { Card as SaltCard, type CardProps as SaltCardProps } from '@salt-ds/core';

export interface CardProps extends SaltCardProps {
  /**
   * Card variant
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary' | 'tertiary' | 'ghost';
  /**
   * Whether the card is hoverable
   * @default false
   */
  hoverable?: boolean;
  /**
   * Whether the card is interactable
   * @default false
   */
  interactable?: boolean;
}

/**
 * Card component wrapper around Salt Design System Card
 * Provides a simplified API while using Salt components internally
 */
export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ variant = 'primary', hoverable = false, interactable = false, className, ...props }, ref) => {
    const saltProps: SaltCardProps = {
      ...props,
      variant,
      hoverable,
      interactable,
      className,
    };

    return <SaltCard {...saltProps} ref={ref} />;
  }
);

Card.displayName = 'Card';

