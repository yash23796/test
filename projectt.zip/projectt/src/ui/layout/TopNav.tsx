import React from 'react';
import { Button } from '../components/Button';

export interface TopNavAction {
  label: string;
  onClick: () => void;
  icon?: React.ReactNode;
}

export interface TopNavProps {
  /**
   * Product name
   */
  productName?: string;
  /**
   * Optional actions (help, about, etc.)
   */
  actions?: TopNavAction[];
  /**
   * Additional className
   */
  className?: string;
}

/**
 * TopNav - Top navigation bar with product name and optional actions
 * Uses Salt components and theme
 */
export const TopNav: React.FC<TopNavProps> = ({
  productName = 'DataDash',
  actions = [],
  className = ''
}) => {
  return (
    <nav
      className={`sticky top-0 z-50 border-b ${className}`}
      style={{
        backgroundColor: 'var(--salt-color-white)',
        borderColor: 'var(--salt-color-gray-200)'
      }}
      role="navigation"
      aria-label="Main navigation"
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Product Name / Logo */}
          <div className="flex items-center gap-2">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(to bottom right, var(--salt-color-blue-600), var(--salt-color-blue-700))'
              }}
            >
              <span className="text-white font-bold text-lg">D</span>
            </div>
            <span className="text-xl font-semibold" style={{ color: 'var(--salt-color-gray-900)' }}>
              {productName}
            </span>
          </div>

          {/* Actions */}
          {actions.length > 0 && (
            <div className="flex items-center gap-2">
              {actions.map((action, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  onClick={action.onClick}
                  icon={action.icon}
                >
                  {action.label}
                </Button>
              ))}
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

