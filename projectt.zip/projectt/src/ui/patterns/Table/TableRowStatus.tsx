import React from 'react';
import { Badge } from '../../components/Badge';
import { SuccessTickIcon, ErrorSolidIcon, WarningSolidIcon, InfoSolidIcon } from '@salt-ds/icons';

export type RowStatusType = 'success' | 'warning' | 'error' | 'info' | 'neutral';

export interface TableRowStatusProps {
  /**
   * Status type
   */
  status: RowStatusType;
  /**
   * Status label text
   */
  label?: string;
  /**
   * Show icon
   * @default true
   */
  showIcon?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * TableRowStatus - Consistent row status indicator
 * Uses Salt Badge with semantic status colors
 */
export const TableRowStatus: React.FC<TableRowStatusProps> = ({
  status,
  label,
  showIcon = true,
  className
}) => {
  const statusConfig = {
    success: {
      icon: <SuccessTickIcon size={0.75} />,
      color: 'var(--salt-status-success-foreground)'
    },
    warning: {
      icon: <WarningSolidIcon size={0.75} />,
      color: 'var(--salt-status-warning-foreground)'
    },
    error: {
      icon: <ErrorSolidIcon size={0.75} />,
      color: 'var(--salt-status-error-foreground)'
    },
    info: {
      icon: <InfoSolidIcon size={0.75} />,
      color: 'var(--salt-status-info-foreground)'
    },
    neutral: {
      icon: null,
      color: 'var(--salt-content-secondary-foreground)'
    }
  };

  const config = statusConfig[status];

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} className={className || ''}>
      {showIcon && config.icon && (
        <span style={{ color: config.color, display: 'flex', alignItems: 'center' }}>
          {config.icon}
        </span>
      )}
      {label && (
        <Badge value={label} />
      )}
    </div>
  );
};

