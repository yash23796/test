import React from 'react';
import { Dropdown as SaltDropdown, type DropdownProps as SaltDropdownProps } from '@salt-ds/core';

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps extends Omit<SaltDropdownProps, 'children' | 'value' | 'onSelectionChange' | 'onChange'> {
  /**
   * Select variant
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary';
  /**
   * Options to display in the select
   */
  options?: SelectOption[];
  /**
   * Selected value
   */
  value?: string;
  /**
   * Placeholder text
   */
  placeholder?: string;
  /**
   * Validation status
   */
  validationStatus?: 'error' | 'warning' | 'success';
  /**
   * Whether the select is disabled
   */
  disabled?: boolean;
  /**
   * Whether the select is required
   */
  required?: boolean;
  /**
   * onChange handler (simplified API)
   */
  onChange?: (value: string) => void;
}

/**
 * Select component wrapper around Salt Design System Dropdown
 * Provides a simplified API while using Salt components internally
 */
export const Select = React.forwardRef<HTMLButtonElement, SelectProps>(
  ({ variant = 'primary', options = [], value, placeholder, validationStatus, disabled, required, onChange, className, ...props }, ref) => {
    const handleSelectionChange = (_event: React.SyntheticEvent, selected: string[]) => {
      if (onChange && selected.length > 0) {
        onChange(selected[0]);
      } else if (onChange && selected.length === 0) {
        onChange('');
      }
    };

    // Convert value to selected array format
    const selected = value ? [value] : [];

    const saltProps: SaltDropdownProps = {
      ...props,
      variant,
      value: value || placeholder || '',
      placeholder,
      validationStatus,
      disabled,
      required,
      className,
      selected,
      onSelectionChange: onChange ? handleSelectionChange : undefined,
      children: options.map((option) => (
        <div key={option.value} data-value={option.value} data-disabled={option.disabled}>
          {option.label}
        </div>
      )),
    };

    return <SaltDropdown {...saltProps} ref={ref} />;
  }
);

Select.displayName = 'Select';

