import React from 'react';
import { Badge } from '../../components/Badge';
import { CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-react';

export type RowStatusType = 'success' | 'warning' | 'error' | 'info' | 'neutral';

export interface TableRowStatusProps {
  /**
   * Status type
   */
  status: RowStatusType;
  /**
   * Status label text
   */
  label?: string;
  /**
   * Show icon
   * @default true
   */
  showIcon?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * TableRowStatus - Consistent row status indicator
 * Uses Salt Badge with semantic status colors
 */
export const TableRowStatus: React.FC<TableRowStatusProps> = ({
  status,
  label,
  showIcon = true,
  className
}) => {
  const statusConfig = {
    success: {
      icon: <CheckCircle className="w-3 h-3" />,
      color: 'var(--salt-color-green-600)',
      bgColor: 'var(--salt-color-green-50)',
      textColor: 'var(--salt-color-green-900)'
    },
    warning: {
      icon: <AlertTriangle className="w-3 h-3" />,
      color: 'var(--salt-color-orange-600)',
      bgColor: 'var(--salt-color-orange-50)',
      textColor: 'var(--salt-color-orange-900)'
    },
    error: {
      icon: <XCircle className="w-3 h-3" />,
      color: 'var(--salt-color-red-600)',
      bgColor: 'var(--salt-color-red-50)',
      textColor: 'var(--salt-color-red-900)'
    },
    info: {
      icon: <Info className="w-3 h-3" />,
      color: 'var(--salt-color-blue-600)',
      bgColor: 'var(--salt-color-blue-50)',
      textColor: 'var(--salt-color-blue-900)'
    },
    neutral: {
      icon: null,
      color: 'var(--salt-color-gray-600)',
      bgColor: 'var(--salt-color-gray-50)',
      textColor: 'var(--salt-color-gray-900)'
    }
  };

  const config = statusConfig[status];

  return (
    <div className={`flex items-center gap-2 ${className || ''}`}>
      {showIcon && config.icon && (
        <span style={{ color: config.color }}>
          {config.icon}
        </span>
      )}
      {label && (
        <Badge 
          value={label}
          style={{
            backgroundColor: config.bgColor,
            color: config.textColor,
            borderColor: config.color
          }}
        />
      )}
    </div>
  );
};

