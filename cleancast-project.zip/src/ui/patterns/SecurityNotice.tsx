import React from 'react';
import { Card } from '../components/Card';
import { AlertCircle } from 'lucide-react';

export interface SecurityNoticeProps {
  /**
   * Title text
   * @default '100% Secure'
   */
  title?: string;
  /**
   * Description text
   */
  description?: string;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * SecurityNotice - Displays security/privacy notice
 * Uses Salt Card component with consistent styling
 */
export const SecurityNotice: React.FC<SecurityNoticeProps> = ({
  title = '100% Secure',
  description = 'Your data is processed entirely in your browser. We never upload or store your sensitive information on any server.',
  className
}) => {
  return (
    <Card variant="primary" className={`p-6 ${className || ''}`}>
      <div className="flex items-start gap-3">
        <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: 'var(--salt-color-green-600)' }} />
        <div>
          <h4 className="mb-1 font-medium">{title}</h4>
          <p className="text-sm">{description}</p>
        </div>
      </div>
    </Card>
  );
};

