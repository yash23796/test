import { useState, useEffect } from 'react';
import { Download, CheckCircle, AlertTriangle, Edit, RefreshCw, Copy, FileText, Check } from 'lucide-react';
import { Button, Card } from '../ui';
import { UploadedFile, BankTemplate, FieldMapping } from '../App';
import { useToast } from '../ui/hooks/useToast';
import { StickyFooter } from './StickyFooter';
import { validateData, ValidationResult as ValidationResultType } from '../utils/dataValidation';
import { transformData, generateCSV } from '../utils/dataTransformation';
import { EditRowModal } from './EditRowModal';
import { ConfirmDiscardDialog, SuccessState } from '../ui/patterns/Feedback';
import { ValidationSummary, EmptyState } from '../ui/patterns';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

interface ValidationStepProps {
  onBack: () => void;
  uploadedFile: UploadedFile | null;
  selectedTemplate: BankTemplate | null;
  fieldMapping: FieldMapping;
  onStartEdit: (rowIndex?: number, validationErrors?: any[]) => void;
  onDataUpdate: (updatedData: any[]) => void;
}

export function ValidationStep({ 
  onBack: _onBack, 
  uploadedFile, 
  selectedTemplate, 
  fieldMapping,
  onStartEdit,
  onDataUpdate 
}: ValidationStepProps) {
  const [isValidating, setIsValidating] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResultType | null>(null);
  const [transformedData, setTransformedData] = useState<Record<string, any>[]>([]);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [showStartNewConfirm, setShowStartNewConfirm] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const toast = useToast();

  // Handle opening edit modal for single row
  const handleEditRow = (rowIndex: number) => {
    setEditingRowIndex(rowIndex);
    setEditModalOpen(true);
  };

  // Automatically validate when component mounts or data changes
  useEffect(() => {
    if (uploadedFile && selectedTemplate && Object.keys(fieldMapping).length > 0) {
      performValidation();
    }
  }, [uploadedFile, selectedTemplate, fieldMapping]);

  const performValidation = async () => {
    if (!uploadedFile || !selectedTemplate) return;

    setIsValidating(true);

    try {
      // Perform real validation
      const result = validateData(uploadedFile.data, fieldMapping, selectedTemplate);
      setValidationResult(result);

      // Transform data for export
      const transformed = transformData(uploadedFile.data, fieldMapping, selectedTemplate);
      setTransformedData(transformed.data);

      if (result.valid === result.total) {
        toast.success(`All ${result.total} rows are valid and ready for export!`);
      } else {
        toast.warning(`Validation complete: ${result.valid} of ${result.total} rows valid. ${result.errors} errors found.`);
      }
    } catch (error) {
      toast.error('Validation failed. Please check your data.');
      console.error('Validation error:', error);
    } finally {
      setIsValidating(false);
    }
  };

  const handleValidate = async () => {
    await performValidation();
  };

  const generateCSVContent = () => {
    if (!selectedTemplate || transformedData.length === 0) return '';
    
    // Get all fields from template
    const fields = [...selectedTemplate.requiredFields, ...selectedTemplate.optionalFields];
    
    // Generate CSV using transformed data
    return generateCSV(transformedData, fields);
  };

  const handleCopyToClipboard = async () => {
    const csvContent = generateCSVContent();
    
    try {
      await navigator.clipboard.writeText(csvContent);
      setCopied(true);
      toast.success('Data copied to clipboard!', { title: 'Copy successful' });
      
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error('Failed to copy to clipboard');
    }
  };

  const handleExport = async () => {
    if (!selectedTemplate || transformedData.length === 0) {
      toast.error('No data to export');
      return;
    }

    setIsExporting(true);

    try {
      // Generate CSV content from transformed data
      const csvContent = generateCSVContent();
      
      // Create downloadable file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      
      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `${selectedTemplate.name.replace(/\s+/g, '_')}_${timestamp}.csv`;
      
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      
      setExportSuccess(true);
      toast.success(`File exported successfully: ${filename}`, { title: 'Export complete' });
      
      // Hide success state after 5 seconds
      setTimeout(() => setExportSuccess(false), 5000);
    } catch (error) {
      toast.error('Failed to export file');
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };

  // Handle saving edits from modal
  const handleSaveRow = (rowIndex: number, updatedRow: Record<string, any>) => {
    if (!uploadedFile) return;

    const newData = [...uploadedFile.data];
    newData[rowIndex] = updatedRow;
    
    // Update the uploaded file data
    onDataUpdate(newData);
    
    // Re-validate
    performValidation();
    
    toast.success('Row updated successfully', { title: 'Update complete' });
    setEditModalOpen(false);
  };

  if (!uploadedFile || !selectedTemplate) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Missing Data"
          description="Please upload a file and select a template to continue."
        />
      </Page>
    );
  }

  // Show loading state while validating
  if (!validationResult && isValidating) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Validating your data..."
          description="Please wait while we validate your data."
        />
      </Page>
    );
  }

  return (
    <Page maxWidth="4xl" className="pb-32">
      <PageHeader
        title="Validate & Export"
        description="Review validation results and download your formatted file."
        primaryAction={
          validationResult && validationResult.valid > 0
            ? {
                label: isExporting ? 'Exporting...' : 'Download CSV',
                onClick: handleExport,
                icon: isExporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />,
                disabled: isExporting || !validationResult
              }
            : undefined
        }
        secondaryActions={
          validationResult && validationResult.errors > 0
            ? [
                {
                  label: 'Edit Data',
                  onClick: () => onStartEdit(undefined, validationResult?.errorDetails || []),
                  icon: <Edit className="w-4 h-4" />
                }
              ]
            : []
        }
      />

      <Stack gap="lg">

        {/* Export Success State */}
        {exportSuccess && validationResult && validationResult.valid > 0 && (
          <SuccessState
            title="Export Complete!"
            message={`Your file has been downloaded successfully. ${validationResult.valid} rows exported.`}
            primaryAction={{
              label: 'Start New Import',
              onClick: () => setShowStartNewConfirm(true),
              icon: <RefreshCw className="w-4 h-4" />
            }}
            secondaryActions={[
              {
                label: 'Download Again',
                onClick: handleExport,
                icon: <Download className="w-4 h-4" />
              }
            ]}
          />
        )}

        {/* Validation Summary */}
        {validationResult && !exportSuccess && (
          <ValidationSummary
            valid={validationResult.valid}
            total={validationResult.total}
            errors={validationResult.errors}
            errorDetails={validationResult.errorDetails}
            showErrorDetails={validationResult.errors > 0 && !isValidating}
            onRevalidate={handleValidate}
            onEditAll={() => onStartEdit(undefined, validationResult?.errorDetails || [])}
            onEditRow={handleEditRow}
            isValidating={isValidating}
          />
        )}

        {/* Dashboard Cards */}
        {validationResult && (
          <Section title="Validation Summary">
            <div className="grid grid-cols-3 gap-4">
          <Card className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
            <div className="flex items-center gap-3 mb-2">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
              <h3 className="text-sm font-medium text-emerald-900">Valid Rows</h3>
            </div>
            <div className="text-3xl font-bold text-emerald-700">{validationResult.valid}</div>
            <p className="text-xs text-emerald-600 mt-1">Ready for export</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-red-200">
            <div className="flex items-center gap-3 mb-2">
              <AlertTriangle className="w-6 h-6 text-red-600" />
              <h3 className="text-sm font-medium text-red-900">Errors</h3>
            </div>
            <div className="text-3xl font-bold text-red-700">{validationResult.errors}</div>
            <p className="text-xs text-red-600 mt-1">Need correction</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <div className="flex items-center gap-3 mb-2">
              <FileText className="w-6 h-6 text-blue-600" />
              <h3 className="text-sm font-medium text-blue-900">Total Records</h3>
            </div>
            <div className="text-3xl font-bold text-blue-700">{validationResult.total}</div>
            <p className="text-xs text-blue-600 mt-1">{selectedTemplate?.name}</p>
          </Card>
        </div>
          </Section>
        )}
      </Stack>

      {/* Sticky Footer with CTAs - Always Visible */}
      <StickyFooter hideBack hideNext>
        <div className="flex justify-between items-center w-full">
          <div className="flex items-center gap-3">
            <Button 
              onClick={() => setShowStartNewConfirm(true)}
              variant="outline"
            >
              Start New
            </Button>
            {validationResult && validationResult.errors > 0 && (
              <Button 
                variant="outline" 
                onClick={() => onStartEdit(undefined, validationResult?.errorDetails || [])}
                className="text-blue-700 border-blue-300 hover:bg-blue-50"
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit Data
              </Button>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {validationResult && validationResult.valid > 0 && (
              <>
                <Button 
                  onClick={handleCopyToClipboard}
                  disabled={copied}
                  variant="outline"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-2 text-green-600" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy CSV
                    </>
                  )}
                </Button>
                <Button 
                  onClick={handleExport}
                  disabled={isExporting || !validationResult}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white disabled:bg-gray-400"
                >
                  {isExporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Download CSV
                    </>
                  )}
                </Button>
              </>
            )}
            {(!validationResult || validationResult.valid === 0) && (
              <Button 
                disabled
                className="bg-gray-400 text-white cursor-not-allowed"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CSV
              </Button>
            )}
          </div>
        </div>
      </StickyFooter>

      {/* Edit Row Modal */}
      {editModalOpen && editingRowIndex !== null && uploadedFile && (
        <EditRowModal
          isOpen={editModalOpen}
          onClose={() => setEditModalOpen(false)}
          rowIndex={editingRowIndex}
          rowData={uploadedFile.data[editingRowIndex]}
          fieldMapping={fieldMapping}
          template={selectedTemplate}
          errors={validationResult?.errorDetails || []}
          onSave={handleSaveRow}
        />
      )}

      {/* Start New Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showStartNewConfirm}
        onOpenChange={setShowStartNewConfirm}
        onConfirm={() => window.location.reload()}
        title="Start a new import?"
        description="This will clear all your current data and start over. This action cannot be undone."
        context="current import"
      />
    </Page>
  );
}