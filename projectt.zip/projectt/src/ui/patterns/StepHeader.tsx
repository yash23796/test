import React from 'react';

export interface StepHeaderProps {
  /**
   * Main title
   */
  title: string;
  /**
   * Supporting description text
   */
  description?: string;
  /**
   * Right-side action buttons
   */
  actions?: React.ReactNode;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * StepHeader - Consistent header pattern for workflow steps
 * Title + description + optional right-side actions
 */
export const StepHeader: React.FC<StepHeaderProps> = ({
  title,
  description,
  actions,
  className
}) => {
  return (
    <div className={`mb-6 ${className || ''}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <h1 className="text-3xl font-semibold mb-2">{title}</h1>
          {description && (
            <p className="text-sm">{description}</p>
          )}
        </div>
        {actions && (
          <div className="flex items-center gap-2 flex-shrink-0">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
};

