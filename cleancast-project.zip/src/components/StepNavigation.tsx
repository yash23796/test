import { Stepper, Step } from '@salt-ds/core';

interface StepNavigationProps {
  currentStep: number;
  steps: string[];
  onStepClick: (stepIndex: number) => void;
}

export function StepNavigation({ currentStep, steps, onStepClick }: StepNavigationProps) {
  return (
    <div className="sticky top-0 z-10 border-b" style={{
      backgroundColor: 'var(--salt-color-white)',
      borderColor: 'var(--salt-separable-borderColor)'
    }}>
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-center py-6">
          <Stepper orientation="horizontal">
            {steps.map((step, index) => {
              const stepNumber = index + 1;
              const isCompleted = currentStep > stepNumber;
              const isCurrent = currentStep === stepNumber;
              
              // Determine step stage based on state
              let stage: 'pending' | 'locked' | 'completed' | 'inprogress' | 'active' = 'pending';
              if (isCompleted) {
                stage = 'completed';
              } else if (isCurrent) {
                stage = 'active';
              } else {
                stage = 'pending';
              }
              
              return (
                <Step
                  key={step}
                  label={step}
                  stage={stage}
                  onToggle={() => {
                    // Only allow clicking on completed or current steps
                    if (stepNumber <= currentStep) {
                      onStepClick(stepNumber);
                    }
                  }}
                  style={{
                    cursor: stepNumber <= currentStep ? 'pointer' : 'default'
                  }}
                />
              );
            })}
          </Stepper>
        </div>
      </div>
    </div>
  );
}
