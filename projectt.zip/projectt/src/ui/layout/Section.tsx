import React from 'react';
import { Stack } from './Stack';

export interface SectionProps {
  /**
   * Section title (H2)
   */
  title?: string;
  /**
   * Section description/helper text
   */
  description?: string;
  /**
   * Section content
   */
  children: React.ReactNode;
  /**
   * Additional className for container
   */
  className?: string;
  /**
   * Additional className for title
   */
  titleClassName?: string;
  /**
   * Additional className for description
   */
  descriptionClassName?: string;
}

/**
 * Section - Standardized section container with title and description
 * Uses proper heading hierarchy (H2 for sections)
 */
export const Section: React.FC<SectionProps> = ({
  title,
  description,
  children,
  className = '',
  titleClassName = '',
  descriptionClassName = ''
}) => {
  return (
    <section className={className}>
      <Stack gap="sm">
        {title && (
          <h2 className={`text-xl font-semibold ${titleClassName}`} style={{ color: 'var(--salt-color-gray-900)' }}>
            {title}
          </h2>
        )}
        {description && (
          <p className={`text-sm ${descriptionClassName}`} style={{ color: 'var(--salt-color-gray-600)' }}>
            {description}
          </p>
        )}
        <div>
          {children}
        </div>
      </Stack>
    </section>
  );
};

