import React from 'react';
import { Badge as SaltBadge, type BadgeProps as SaltBadgeProps } from '@salt-ds/core';

export interface BadgeProps extends SaltBadgeProps {
  /**
   * Badge value to display
   */
  value?: number | string;
  /**
   * Maximum value to display (if value exceeds max, shows max+)
   */
  max?: number;
  /**
   * If provided, badge renders as a dot
   */
  dot?: boolean;
}

/**
 * Badge component wrapper around Salt Design System Badge
 * Provides a simplified API while using Salt components internally
 * Typography is handled via global CSS to ensure Open Sans per JPM Brand guidance
 */
export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ value, max, dot, children, className, ...props }, ref) => {
    const saltProps: SaltBadgeProps = {
      ...props,
      value: dot ? undefined : value,
      max,
      className,
    };

    return <SaltBadge {...saltProps} ref={ref}>{children}</SaltBadge>;
  }
);

Badge.displayName = 'Badge';

