import { useState, useEffect } from 'react';
import { Banner, Button, Card, Text, H4, ToggleButtonGroup, ToggleButton } from '@salt-ds/core';
import { DownloadIcon, SuccessTickIcon, ErrorSolidIcon, RefreshIcon, CopyIcon, DocumentIcon } from '@salt-ds/icons';
import { AgGridReact } from 'ag-grid-react';
import { ClientSideRowModelModule } from 'ag-grid-community';
import { ModuleRegistry } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { UploadedFile, BankTemplate, FieldMapping } from '../App';
import { StickyFooter } from './StickyFooter';
import { validateData, ValidationResult as ValidationResultType, ValidationError } from '../utils/dataValidation';
import { transformData, generateCSV } from '../utils/dataTransformation';
import { EditRowModal } from './EditRowModal';
import { ConfirmDiscardDialog, SuccessState } from '../ui/patterns/Feedback';
import { EmptyState } from '../ui/patterns';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

// Register AG Grid modules
ModuleRegistry.registerModules([ClientSideRowModelModule]);

// Cell Renderer Component for Action Button
const ActionCellRenderer = (props: any) => {
  if (!props.data) return null;
  
  return (
    <Button
      variant="secondary"
      sentiment="neutral"
      onClick={() => props.context.handleEditRow(props.data._rowIndex)}
    >
      Fix
    </Button>
  );
};

interface ValidationStepProps {
  onBack: () => void;
  uploadedFile: UploadedFile | null;
  selectedTemplate: BankTemplate | null;
  fieldMapping: FieldMapping;
  onStartEdit: (rowIndex?: number, validationErrors?: any[]) => void;
  onDataUpdate: (updatedData: any[]) => void;
  onValidationStatusChange?: (status: 'pending' | 'success' | 'error') => void;
}

export function ValidationStep({ 
  onBack: _onBack, 
  uploadedFile, 
  selectedTemplate, 
  fieldMapping,
  onStartEdit: _onStartEdit,
  onDataUpdate,
  onValidationStatusChange
}: ValidationStepProps) {
  const [isValidating, setIsValidating] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResultType | null>(null);
  const [transformedData, setTransformedData] = useState<Record<string, any>[]>([]);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [showStartNewConfirm, setShowStartNewConfirm] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'errors' | 'valid'>('errors');

  // Handle opening edit modal for single row
  const handleEditRow = (rowIndex: number) => {
    setEditingRowIndex(rowIndex);
    setEditModalOpen(true);
  };

  // Automatically validate when component mounts or data changes
  useEffect(() => {
    if (uploadedFile && selectedTemplate && Object.keys(fieldMapping).length > 0) {
      performValidation();
    }
  }, [uploadedFile, selectedTemplate, fieldMapping]);

  const performValidation = async () => {
    if (!uploadedFile || !selectedTemplate) return;

    setIsValidating(true);

    try {
      // Perform real validation
      const result = validateData(uploadedFile.data, fieldMapping, selectedTemplate);
      setValidationResult(result);

      // Update validation status for stepper
      if (onValidationStatusChange) {
        // Only show success when ALL errors are fixed (errors === 0)
        if (result.errors === 0) {
          onValidationStatusChange('success');
        } else {
          onValidationStatusChange('error');
        }
      }

      // Transform data for export
      const transformed = transformData(uploadedFile.data, fieldMapping, selectedTemplate);
      setTransformedData(transformed.data);

      // Don't show banner on initial load, only show in ValidationSummary component
    } catch (error) {
      console.error('Validation error:', error);
      if (onValidationStatusChange) {
        onValidationStatusChange('error');
      }
    } finally {
      setIsValidating(false);
    }
  };

  const handleValidate = async () => {
    await performValidation();
  };

  const generateCSVContent = () => {
    if (!selectedTemplate || transformedData.length === 0) return '';
    
    // Get all fields from template
    const fields = [...selectedTemplate.requiredFields, ...selectedTemplate.optionalFields];
    
    // Generate CSV using transformed data
    return generateCSV(transformedData, fields);
  };

  const handleCopyToClipboard = async () => {
    const csvContent = generateCSVContent();
    
    try {
      await navigator.clipboard.writeText(csvContent);
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
      }, 3000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const handleExport = async () => {
    if (!selectedTemplate || transformedData.length === 0) {
      console.error('No data to export');
      return;
    }

    setIsExporting(true);

    try {
      // Generate CSV content from transformed data
      const csvContent = generateCSVContent();
      
      // Create downloadable file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      
      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `${selectedTemplate.name.replace(/\s+/g, '_')}_${timestamp}.csv`;
      
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      
      setExportSuccess(true);
      
      // Hide success state after 5 seconds
      setTimeout(() => {
        setExportSuccess(false);
      }, 5000);
    } catch (error) {
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };

  // Handle saving edits from modal
  const handleSaveRow = (rowIndex: number, updatedRow: Record<string, any>) => {
    if (!uploadedFile) return;

    const newData = [...uploadedFile.data];
    newData[rowIndex] = updatedRow;
    
    // Update the uploaded file data
    onDataUpdate(newData);
    
    // Re-validate
    performValidation();
    
    setEditModalOpen(false);
  };

  if (!uploadedFile || !selectedTemplate) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Missing Data"
          description="Please upload a file and select a template to continue."
        />
      </Page>
    );
  }

  // Show loading state while validating
  if (!validationResult && isValidating) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Validating your data..."
          description="Please wait while we validate your data."
        />
      </Page>
    );
  }

  return (
    <Page maxWidth="4xl" className="pb-32">
      <PageHeader
        title="Validate & Export"
        description="Review validation results and download your formatted file."
      />

      <Stack gap="lg">

        {/* Export Success State */}
        {exportSuccess && validationResult && validationResult.valid > 0 && (
          <SuccessState
            title="Export Complete!"
            message={`Your file has been downloaded successfully. ${validationResult.valid} rows exported.`}
            primaryAction={{
              label: 'Start New Import',
              onClick: () => setShowStartNewConfirm(true),
              icon: <RefreshIcon size={1} />
            }}
            secondaryActions={[
              {
                label: 'Download Again',
                onClick: handleExport,
                icon: <DownloadIcon size={1} />
              }
            ]}
          />
        )}

        {/* Validation Summary Banner (always shown first) */}
        {validationResult && !exportSuccess && (
          <>
            <div className="sticky top-0 z-10 mb-6">
              <Banner 
                status={validationResult.errors > 0 ? 'error' : 'success'}
                variant="secondary"
                style={{ borderRadius: '8px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <Text style={{ fontWeight: 600 }}>
                      {validationResult.errors === 0 
                        ? 'All rows are successfully validated' 
                        : `${validationResult.valid} of ${validationResult.total} rows valid`
                      }
                    </Text>
                    {validationResult.errors > 0 && (
                      <Text style={{ display: 'block', marginTop: '0.25rem' }}>
                        {validationResult.errors} errors must be fixed before export
                      </Text>
                    )}
                  </div>
                  {validationResult.errors > 0 && (
                    <Button 
                      variant="secondary"
                      onClick={handleValidate}
                      disabled={isValidating}
                    >
                      {isValidating ? <RefreshIcon size={1} style={{ animation: 'spin 1s linear infinite' }} /> : null}
                      Re-validate
                    </Button>
                  )}
                </div>
              </Banner>
            </div>

            {/* Validation Summary Cards */}
            <Section title="Validation Summary">
              <div className="grid grid-cols-3 gap-4">
                <Card style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                    <SuccessTickIcon size={1.5} style={{ color: 'var(--salt-status-success-foreground)' }} />
                    <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Valid Rows</H4>
                  </div>
                  <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-status-success-foreground)' }}>{validationResult.valid}</Text>
                  <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>Ready for export</Text>
                </Card>

                <Card style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                    <ErrorSolidIcon size={1.5} style={{ color: 'var(--salt-status-error-foreground)' }} />
                    <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Errors</H4>
                  </div>
                  <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-status-error-foreground)' }}>{validationResult.errors}</Text>
                  <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>Need correction</Text>
                </Card>

                <Card style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                    <DocumentIcon size={1.5} style={{ color: 'var(--salt-color-accent-foreground)' }} />
                    <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Total Records</H4>
                  </div>
                  <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-color-accent-foreground)' }}>{validationResult.total}</Text>
                  <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>{selectedTemplate?.name}</Text>
                </Card>
              </div>
            </Section>

            {/* Data Table with Tabs */}
            <Card variant="primary" style={{ padding: '1.5rem', borderRadius: '8px' }}>
              <div style={{ marginBottom: '1rem' }}>
                <ToggleButtonGroup 
                  value={activeTab}
                  onChange={(event: React.SyntheticEvent<HTMLButtonElement>) => {
                    const value = (event.currentTarget as HTMLButtonElement).value;
                    if (value) setActiveTab(value as 'errors' | 'valid');
                  }}
                >
                  <ToggleButton value="errors">
                    Errors ({validationResult.errors})
                  </ToggleButton>
                  <ToggleButton value="valid">
                    Valid Rows ({validationResult.valid})
                  </ToggleButton>
                </ToggleButtonGroup>
              </div>
                
              {activeTab === 'errors' && (
                <div style={{ marginTop: '1rem' }}>
                  <div 
                    className="ag-theme-alpine" 
                    style={{ 
                      height: `${Math.max(Math.min((() => {
                        const errorRows: any[] = [];
                        transformedData.forEach((row, index) => {
                          const errors = validationResult.errorDetails?.filter(e => e.row === index + 1) || [];
                          if (errors.length > 0) {
                            errorRows.push(row);
                          }
                        });
                        return errorRows;
                      })().length, 10) * 32 + 36 + 2, 150)}px`,
                      width: '100%',
                      '--ag-background-color': 'var(--salt-container-primary-background)',
                      '--ag-header-background-color': 'var(--salt-container-secondary-background)',
                      '--ag-foreground-color': 'var(--salt-content-primary-foreground)',
                      '--ag-border-color': 'var(--salt-separable-primary-borderColor)',
                      '--ag-row-hover-color': 'var(--salt-selectable-background-hover)',
                      borderRadius: 'var(--salt-size-container-radius)',
                      boxShadow: 'var(--salt-shadow-1)',
                      overflow: 'auto'
                    } as any}
                  >
                    <AgGridReact
                      rowData={(() => {
                        const errorRows: any[] = [];
                        transformedData.forEach((row, index) => {
                          const errors = validationResult.errorDetails?.filter(e => e.row === index + 1) || [];
                          if (errors.length > 0) {
                            errorRows.push({ ...row, _errors: errors, _rowIndex: index });
                          }
                        });
                        return errorRows;
                      })()}
                      columnDefs={selectedTemplate ? [
                        ...selectedTemplate.requiredFields.map(field => ({
                          field: field as any,
                          headerName: field,
                          sortable: true,
                          filter: true,
                          resizable: true,
                          width: 150,
                          cellStyle: (params: any) => {
                            if (!params.data) return { padding: '4px 8px', fontSize: '12px' };
                            const errors = params.data._errors?.filter((e: ValidationError) => e.field === field) || [];
                            const hasError = errors.length > 0;
                            
                            return {
                              padding: '4px 8px',
                              fontSize: '12px',
                              color: hasError ? 'var(--salt-status-error-foreground)' : undefined,
                              backgroundColor: hasError ? 'var(--salt-status-error-background)' : 'transparent',
                              borderLeft: hasError ? '2px solid var(--salt-status-error-borderColor)' : 'none'
                            };
                          },
                          tooltipValueGetter: (params: any) => {
                            if (!params.data) return '';
                            const errors = params.data._errors?.filter((e: ValidationError) => e.field === field) || [];
                            return errors.length > 0 ? errors[0].error : '';
                          }
                        })),
                        ...selectedTemplate.optionalFields.map(field => ({
                          field: field as any,
                          headerName: field,
                          sortable: true,
                          filter: true,
                          resizable: true,
                          width: 150,
                          cellStyle: (params: any) => {
                            if (!params.data) return { padding: '4px 8px', fontSize: '12px' };
                            const errors = params.data._errors?.filter((e: ValidationError) => e.field === field) || [];
                            const hasError = errors.length > 0;
                            
                            return {
                              padding: '4px 8px',
                              fontSize: '12px',
                              color: hasError ? 'var(--salt-status-error-foreground)' : undefined,
                              backgroundColor: hasError ? 'var(--salt-status-error-background)' : 'transparent',
                              borderLeft: hasError ? '2px solid var(--salt-status-error-borderColor)' : 'none'
                            };
                          },
                          tooltipValueGetter: (params: any) => {
                            if (!params.data) return '';
                            const errors = params.data._errors?.filter((e: ValidationError) => e.field === field) || [];
                            return errors.length > 0 ? errors[0].error : '';
                          }
                        })),
                        {
                          field: 'actions' as any,
                          headerName: 'Actions',
                          sortable: false,
                          filter: false,
                          resizable: false,
                          width: 80,
                          pinned: 'right' as any,
                          cellRenderer: ActionCellRenderer,
                          cellStyle: {
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            padding: 0,
                            textAlign: 'center'
                          },
                          cellClass: 'actions-cell-center'
                        }
                      ] as any[] : []}
                      domLayout="normal"
                      headerHeight={36}
                      rowHeight={32}
                      suppressCellFocus={true}
                      enableCellTextSelection={true}
                      suppressHorizontalScroll={false}
                      context={{ handleEditRow }}
                      overlayNoRowsTemplate={'<div style="padding: 2rem; text-align: center; color: var(--salt-content-secondary-foreground); font-size: 14px;">No errors to show</div>'}
                    />
                  </div>
                </div>
              )}
                
              {activeTab === 'valid' && (
                <div style={{ marginTop: '1rem' }}>
                  <div 
                    className="ag-theme-alpine" 
                    style={{ 
                      height: `${Math.max(Math.min(transformedData.filter((_, index) => {
                        const hasError = validationResult.errorDetails?.some(e => e.row === index + 1);
                        return !hasError;
                      }).length, 10) * 32 + 36 + 2, 150)}px`,
                      width: '100%',
                      '--ag-background-color': 'var(--salt-container-primary-background)',
                      '--ag-header-background-color': 'var(--salt-container-secondary-background)',
                      '--ag-foreground-color': 'var(--salt-content-primary-foreground)',
                      '--ag-border-color': 'var(--salt-separable-primary-borderColor)',
                      '--ag-row-hover-color': 'var(--salt-selectable-background-hover)',
                      borderRadius: 'var(--salt-size-container-radius)',
                      boxShadow: 'var(--salt-shadow-1)',
                      overflow: 'auto'
                    } as any}
                  >
                    <AgGridReact
                      rowData={transformedData.filter((_, index) => {
                        const hasError = validationResult.errorDetails?.some(e => e.row === index + 1);
                        return !hasError;
                      })}
                      columnDefs={selectedTemplate ? [
                        ...selectedTemplate.requiredFields.map(field => ({
                          field: field as any,
                          headerName: field,
                          sortable: true,
                          filter: true,
                          resizable: true,
                          width: 150,
                          cellStyle: {
                            fontSize: '12px',
                            padding: '4px 8px'
                          }
                        })),
                        ...selectedTemplate.optionalFields.map(field => ({
                          field: field as any,
                          headerName: field,
                          sortable: true,
                          filter: true,
                          resizable: true,
                          width: 150,
                          cellStyle: {
                            fontSize: '12px',
                            padding: '4px 8px'
                          }
                        }))
                      ] as any[] : []}
                      domLayout="normal"
                      headerHeight={36}
                      rowHeight={32}
                      suppressCellFocus={true}
                      enableCellTextSelection={true}
                      suppressHorizontalScroll={false}
                      overlayNoRowsTemplate={'<div style="padding: 2rem; text-align: center; color: var(--salt-content-secondary-foreground); font-size: 14px;">No valid rows to show</div>'}
                    />
                  </div>
                </div>
              )}
            </Card>
          </>
        )}
      </Stack>

      {/* Sticky Footer with CTAs - Always Visible */}
      <StickyFooter hideBack hideNext>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <Button 
              onClick={() => setShowStartNewConfirm(true)}
              variant="secondary"
            >
              Start New
            </Button>
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {validationResult && validationResult.valid > 0 && (
              <>
                <Button 
                  onClick={handleCopyToClipboard}
                  disabled={copied}
                  variant="secondary"
                >
                  {copied ? (
                    <>
                      <SuccessTickIcon size={1} style={{ marginRight: '0.5rem', color: 'var(--salt-status-success-foreground)' }} />
                      Copied
                    </>
                  ) : (
                    <>
                      <CopyIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Copy CSV
                    </>
                  )}
                </Button>
                <Button 
                  onClick={handleExport}
                  disabled={isExporting || !validationResult}
                  variant="cta"
                >
                  {isExporting ? (
                    <>
                      <RefreshIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <DownloadIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Download CSV
                    </>
                  )}
                </Button>
              </>
            )}
            {(!validationResult || validationResult.valid === 0) && (
              <Button 
                disabled
                variant="cta"
              >
                <DownloadIcon size={1} style={{ marginRight: '0.5rem' }} />
                Download CSV
              </Button>
            )}
          </div>
        </div>
      </StickyFooter>

      {/* Edit Row Modal */}
      {editModalOpen && editingRowIndex !== null && uploadedFile && (
        <EditRowModal
          isOpen={editModalOpen}
          onClose={() => setEditModalOpen(false)}
          rowIndex={editingRowIndex}
          rowData={uploadedFile.data[editingRowIndex]}
          fieldMapping={fieldMapping}
          template={selectedTemplate}
          errors={validationResult?.errorDetails || []}
          onSave={handleSaveRow}
        />
      )}

      {/* Start New Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showStartNewConfirm}
        onOpenChange={setShowStartNewConfirm}
        onConfirm={() => window.location.reload()}
        title="Start a new import?"
        description="This will clear all your current data and start over. This action cannot be undone."
        context="current import"
        confirmText="Start"
      />
    </Page>
  );
}