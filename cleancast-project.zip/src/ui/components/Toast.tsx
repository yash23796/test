import React from 'react';
import { Toast as SaltToast, ToastContent } from '@salt-ds/core';

export type ToastSeverity = 'error' | 'warning' | 'success' | 'info';

export interface ToastProps {
  /**
   * Toast message
   */
  message: string;
  /**
   * Toast severity/status
   * @default 'info'
   */
  severity?: ToastSeverity;
  /**
   * Toast title (optional)
   */
  title?: string;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * Toast component wrapper around Salt Design System Toast
 * Note: This is a display component. For app-wide toast notifications,
 * use the useToast hook which integrates with sonner.
 */
export const Toast: React.FC<ToastProps> = ({
  message,
  severity = 'info',
  title,
  className
}) => {
  return (
    <SaltToast
      status={severity}
      className={className}
    >
      <ToastContent>
        {title && <strong>{title}</strong>}
        <div>{message}</div>
      </ToastContent>
    </SaltToast>
  );
};

