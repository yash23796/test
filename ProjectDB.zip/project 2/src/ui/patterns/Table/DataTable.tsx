import React from 'react';
import { Card } from '../../components/Card';
import { EmptyState } from '../EmptyState';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../../components/ui/table';

export interface DataTableColumn<T = any> {
  /**
   * Column header label
   */
  header: string;
  /**
   * Accessor function or key to get cell value
   */
  accessor: string | ((row: T) => React.ReactNode);
  /**
   * Column width (optional)
   */
  width?: string;
  /**
   * Whether column should not wrap
   * @default false
   */
  noWrap?: boolean;
  /**
   * Custom cell renderer
   */
  cell?: (value: any, row: T, index: number) => React.ReactNode;
}

export interface DataTableProps<T = any> {
  /**
   * Table columns configuration
   */
  columns: DataTableColumn<T>[];
  /**
   * Table data rows
   */
  data: T[];
  /**
   * Loading state
   * @default false
   */
  isLoading?: boolean;
  /**
   * Empty state configuration
   */
  emptyState?: {
    title: string;
    description?: string;
    action?: {
      label: string;
      onClick: () => void;
    };
  };
  /**
   * Row key generator
   */
  getRowKey?: (row: T, index: number) => string | number;
  /**
   * Row className generator
   */
  getRowClassName?: (row: T, index: number) => string;
  /**
   * Table title (optional)
   */
  title?: string;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * DataTable - Base table wrapper with consistent styling
 * Uses Salt components and provides empty/loading states
 */
export function DataTable<T = any>({
  columns,
  data,
  isLoading = false,
  emptyState,
  getRowKey = (_, index) => index,
  getRowClassName,
  title,
  className
}: DataTableProps<T>) {
  const getCellValue = (row: T, accessor: string | ((row: T) => React.ReactNode)): React.ReactNode => {
    if (typeof accessor === 'function') {
      return accessor(row);
    }
    return (row as any)[accessor] ?? '-';
  };

  if (isLoading) {
    return (
      <Card variant="primary" className={`p-12 text-center ${className || ''}`}>
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{
            borderColor: 'var(--salt-color-blue-600)',
            borderTopColor: 'transparent'
          }}></div>
          <p>Loading data...</p>
        </div>
      </Card>
    );
  }

  if (data.length === 0 && emptyState) {
    return (
      <Card variant="primary" className={className || ''}>
        <EmptyState
          title={emptyState.title}
          description={emptyState.description}
          action={emptyState.action}
        />
      </Card>
    );
  }

  if (data.length === 0) {
    return (
      <Card variant="primary" className={`p-12 text-center ${className || ''}`}>
        <p>No data available</p>
      </Card>
    );
  }

  return (
    <Card variant="primary" className={`overflow-hidden ${className || ''}`}>
      {title && (
        <div className="px-4 py-2 border-b" style={{ 
          backgroundColor: 'var(--salt-color-gray-50)',
          borderColor: 'var(--salt-color-gray-200)'
        }}>
          <h4 className="font-medium">{title}</h4>
        </div>
      )}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column, index) => (
                <TableHead
                  key={index}
                  className={column.noWrap ? 'whitespace-nowrap' : ''}
                  style={column.width ? { width: column.width } : undefined}
                >
                  {column.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, rowIndex) => (
              <TableRow
                key={getRowKey(row, rowIndex)}
                className={getRowClassName?.(row, rowIndex)}
              >
                {columns.map((column, colIndex) => {
                  const value = getCellValue(row, column.accessor);
                  return (
                    <TableCell
                      key={colIndex}
                      className={column.noWrap ? 'whitespace-nowrap' : ''}
                    >
                      {column.cell ? column.cell(value, row, rowIndex) : value}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}

