import React from 'react';
import { Dropdown, Option } from '@salt-ds/core';

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps {
  /**
   * Select variant
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary';
  /**
   * Options to display in the select
   */
  options?: SelectOption[];
  /**
   * Selected value
   */
  value?: string;
  /**
   * Placeholder text
   */
  placeholder?: string;
  /**
   * Validation status
   */
  validationStatus?: 'error' | 'warning' | 'success';
  /**
   * Whether the select is disabled
   */
  disabled?: boolean;
  /**
   * Whether the select is required
   */
  required?: boolean;
  /**
   * onChange handler (simplified API)
   */
  onChange?: (value: string) => void;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * Select component wrapper around Salt Design System Dropdown
 * Provides a simplified API while using Salt components internally
 */
export const Select = React.forwardRef<HTMLButtonElement, SelectProps>(
  ({ options = [], value, placeholder = 'Select...', validationStatus, disabled, onChange, className }, ref) => {
    const handleSelectionChange = (_event: React.SyntheticEvent, selected: string[]) => {
      if (onChange && selected.length > 0) {
        onChange(selected[0]);
      } else if (onChange && selected.length === 0) {
        onChange('');
      }
    };

    // Find the label for the selected value
    const selectedOption = options.find(opt => opt.value === value);
    const displayValue = selectedOption ? selectedOption.label : '';

    return (
      <Dropdown
        ref={ref}
        selected={value ? [value] : []}
        onSelectionChange={handleSelectionChange}
        value={displayValue}
        placeholder={placeholder}
        validationStatus={validationStatus}
        disabled={disabled}
        className={className}
        style={{ width: '100%' }}
      >
        {options.map((option) => (
          <Option 
            key={option.value} 
            value={option.value}
            disabled={option.disabled}
          >
            {option.label}
          </Option>
        ))}
      </Dropdown>
    );
  }
);

Select.displayName = 'Select';

