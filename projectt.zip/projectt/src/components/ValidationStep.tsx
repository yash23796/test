import { useState, useEffect } from 'react';
import { Banner, Button, Card, Text, H3, H4 } from '@salt-ds/core';
import { DownloadIcon, SuccessTickIcon, ErrorSolidIcon, EditIcon, RefreshIcon, CopyIcon, DocumentIcon } from '@salt-ds/icons';
import { UploadedFile, BankTemplate, FieldMapping } from '../App';
import { StickyFooter } from './StickyFooter';
import { validateData, ValidationResult as ValidationResultType } from '../utils/dataValidation';
import { transformData, generateCSV } from '../utils/dataTransformation';
import { EditRowModal } from './EditRowModal';
import { ConfirmDiscardDialog, SuccessState } from '../ui/patterns/Feedback';
import { ValidationSummary, EmptyState } from '../ui/patterns';
import { Page, PageHeader, Section, Stack } from '../ui/layout';

interface ValidationStepProps {
  onBack: () => void;
  uploadedFile: UploadedFile | null;
  selectedTemplate: BankTemplate | null;
  fieldMapping: FieldMapping;
  onStartEdit: (rowIndex?: number, validationErrors?: any[]) => void;
  onDataUpdate: (updatedData: any[]) => void;
}

export function ValidationStep({ 
  onBack: _onBack, 
  uploadedFile, 
  selectedTemplate, 
  fieldMapping,
  onStartEdit,
  onDataUpdate 
}: ValidationStepProps) {
  const [isValidating, setIsValidating] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResultType | null>(null);
  const [transformedData, setTransformedData] = useState<Record<string, any>[]>([]);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [showStartNewConfirm, setShowStartNewConfirm] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [showBanner, setShowBanner] = useState(false);
  const [bannerMessage, setBannerMessage] = useState('');
  const [bannerStatus, setBannerStatus] = useState<'success' | 'warning' | 'error'>('success');

  // Handle opening edit modal for single row
  const handleEditRow = (rowIndex: number) => {
    setEditingRowIndex(rowIndex);
    setEditModalOpen(true);
  };

  // Automatically validate when component mounts or data changes
  useEffect(() => {
    if (uploadedFile && selectedTemplate && Object.keys(fieldMapping).length > 0) {
      performValidation();
    }
  }, [uploadedFile, selectedTemplate, fieldMapping]);

  const performValidation = async () => {
    if (!uploadedFile || !selectedTemplate) return;

    setIsValidating(true);

    try {
      // Perform real validation
      const result = validateData(uploadedFile.data, fieldMapping, selectedTemplate);
      setValidationResult(result);

      // Transform data for export
      const transformed = transformData(uploadedFile.data, fieldMapping, selectedTemplate);
      setTransformedData(transformed.data);

      if (result.valid === result.total) {
        setBannerMessage(`All ${result.total} rows are valid and ready for export!`);
        setBannerStatus('success');
      } else {
        setBannerMessage(`Validation complete: ${result.valid} of ${result.total} rows valid. ${result.errors} errors found.`);
        setBannerStatus('warning');
      }
      setShowBanner(true);
      setTimeout(() => setShowBanner(false), 5000);
    } catch (error) {
      setBannerMessage('Validation failed. Please check your data.');
      setBannerStatus('error');
      setShowBanner(true);
      setTimeout(() => setShowBanner(false), 5000);
      console.error('Validation error:', error);
    } finally {
      setIsValidating(false);
    }
  };

  const handleValidate = async () => {
    await performValidation();
  };

  const generateCSVContent = () => {
    if (!selectedTemplate || transformedData.length === 0) return '';
    
    // Get all fields from template
    const fields = [...selectedTemplate.requiredFields, ...selectedTemplate.optionalFields];
    
    // Generate CSV using transformed data
    return generateCSV(transformedData, fields);
  };

  const handleCopyToClipboard = async () => {
    const csvContent = generateCSVContent();
    
    try {
      await navigator.clipboard.writeText(csvContent);
      setCopied(true);
      setBannerMessage('Data copied to clipboard!');
      setBannerStatus('success');
      setShowBanner(true);
      setTimeout(() => {
        setCopied(false);
        setShowBanner(false);
      }, 3000);
    } catch (err) {
      setBannerMessage('Failed to copy to clipboard');
      setBannerStatus('error');
      setShowBanner(true);
      setTimeout(() => setShowBanner(false), 3000);
    }
  };

  const handleExport = async () => {
    if (!selectedTemplate || transformedData.length === 0) {
      setBannerMessage('No data to export');
      setBannerStatus('error');
      setShowBanner(true);
      setTimeout(() => setShowBanner(false), 3000);
      return;
    }

    setIsExporting(true);

    try {
      // Generate CSV content from transformed data
      const csvContent = generateCSVContent();
      
      // Create downloadable file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      
      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `${selectedTemplate.name.replace(/\s+/g, '_')}_${timestamp}.csv`;
      
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      
      setExportSuccess(true);
      setBannerMessage(`File exported successfully: ${filename}`);
      setBannerStatus('success');
      setShowBanner(true);
      
      // Hide success state after 5 seconds
      setTimeout(() => {
        setExportSuccess(false);
        setShowBanner(false);
      }, 5000);
    } catch (error) {
      setBannerMessage('Failed to export file');
      setBannerStatus('error');
      setShowBanner(true);
      setTimeout(() => setShowBanner(false), 3000);
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };

  // Handle saving edits from modal
  const handleSaveRow = (rowIndex: number, updatedRow: Record<string, any>) => {
    if (!uploadedFile) return;

    const newData = [...uploadedFile.data];
    newData[rowIndex] = updatedRow;
    
    // Update the uploaded file data
    onDataUpdate(newData);
    
    // Re-validate
    performValidation();
    
    setBannerMessage('Row updated successfully');
    setBannerStatus('success');
    setShowBanner(true);
    setTimeout(() => setShowBanner(false), 3000);
    setEditModalOpen(false);
  };

  if (!uploadedFile || !selectedTemplate) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Missing Data"
          description="Please upload a file and select a template to continue."
        />
      </Page>
    );
  }

  // Show loading state while validating
  if (!validationResult && isValidating) {
    return (
      <Page maxWidth="4xl" className="pb-32">
        <EmptyState
          title="Validating your data..."
          description="Please wait while we validate your data."
        />
      </Page>
    );
  }

  return (
    <Page maxWidth="4xl" className="pb-32">
      {showBanner && (
        <Banner status={bannerStatus} style={{ marginBottom: '1rem' }}>
          <Text>{bannerMessage}</Text>
        </Banner>
      )}
      <PageHeader
        title="Validate & Export"
        description="Review validation results and download your formatted file."
        primaryAction={
          validationResult && validationResult.valid > 0
            ? {
                label: isExporting ? 'Exporting...' : 'Download CSV',
                onClick: handleExport,
                icon: isExporting ? <RefreshIcon size={1} /> : <DownloadIcon size={1} />,
                disabled: isExporting || !validationResult
              }
            : undefined
        }
        secondaryActions={
          validationResult && validationResult.errors > 0
            ? [
                {
                  label: 'Edit Data',
                  onClick: () => onStartEdit(undefined, validationResult?.errorDetails || []),
                  icon: <EditIcon size={1} />
                }
              ]
            : []
        }
      />

      <Stack gap="lg">

        {/* Export Success State */}
        {exportSuccess && validationResult && validationResult.valid > 0 && (
          <SuccessState
            title="Export Complete!"
            message={`Your file has been downloaded successfully. ${validationResult.valid} rows exported.`}
            primaryAction={{
              label: 'Start New Import',
              onClick: () => setShowStartNewConfirm(true),
              icon: <RefreshIcon size={1} />
            }}
            secondaryActions={[
              {
                label: 'Download Again',
                onClick: handleExport,
                icon: <DownloadIcon size={1} />
              }
            ]}
          />
        )}

        {/* Validation Summary */}
        {validationResult && !exportSuccess && (
          <ValidationSummary
            valid={validationResult.valid}
            total={validationResult.total}
            errors={validationResult.errors}
            errorDetails={validationResult.errorDetails}
            showErrorDetails={validationResult.errors > 0 && !isValidating}
            onRevalidate={handleValidate}
            onEditAll={() => onStartEdit(undefined, validationResult?.errorDetails || [])}
            onEditRow={handleEditRow}
            isValidating={isValidating}
          />
        )}

        {/* Dashboard Cards */}
        {validationResult && (
          <Section title="Validation Summary">
            <div className="grid grid-cols-3 gap-4">
              <Card style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                  <SuccessTickIcon size={1.5} style={{ color: 'var(--salt-status-success-foreground)' }} />
                  <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Valid Rows</H4>
                </div>
                <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-status-success-foreground)' }}>{validationResult.valid}</Text>
                <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>Ready for export</Text>
              </Card>

              <Card style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                  <ErrorSolidIcon size={1.5} style={{ color: 'var(--salt-status-error-foreground)' }} />
                  <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Errors</H4>
                </div>
                <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-status-error-foreground)' }}>{validationResult.errors}</Text>
                <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>Need correction</Text>
              </Card>

              <Card style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                  <DocumentIcon size={1.5} style={{ color: 'var(--salt-color-accent-foreground)' }} />
                  <H4 style={{ margin: 0, color: 'var(--salt-content-primary-foreground)' }}>Total Records</H4>
                </div>
                <Text style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--salt-color-accent-foreground)' }}>{validationResult.total}</Text>
                <Text style={{ fontSize: '0.75rem', color: 'var(--salt-content-secondary-foreground)', marginTop: '0.25rem' }}>{selectedTemplate?.name}</Text>
              </Card>
            </div>
          </Section>
        )}
      </Stack>

      {/* Sticky Footer with CTAs - Always Visible */}
      <StickyFooter hideBack hideNext>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <Button 
              onClick={() => setShowStartNewConfirm(true)}
              variant="secondary"
            >
              Start New
            </Button>
            {validationResult && validationResult.errors > 0 && (
              <Button 
                variant="secondary" 
                onClick={() => onStartEdit(undefined, validationResult?.errorDetails || [])}
              >
                <EditIcon size={1} style={{ marginRight: '0.5rem' }} />
                Edit Data
              </Button>
            )}
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {validationResult && validationResult.valid > 0 && (
              <>
                <Button 
                  onClick={handleCopyToClipboard}
                  disabled={copied}
                  variant="secondary"
                >
                  {copied ? (
                    <>
                      <SuccessTickIcon size={1} style={{ marginRight: '0.5rem', color: 'var(--salt-status-success-foreground)' }} />
                      Copied
                    </>
                  ) : (
                    <>
                      <CopyIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Copy CSV
                    </>
                  )}
                </Button>
                <Button 
                  onClick={handleExport}
                  disabled={isExporting || !validationResult}
                  variant="cta"
                >
                  {isExporting ? (
                    <>
                      <RefreshIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <DownloadIcon size={1} style={{ marginRight: '0.5rem' }} />
                      Download CSV
                    </>
                  )}
                </Button>
              </>
            )}
            {(!validationResult || validationResult.valid === 0) && (
              <Button 
                disabled
                variant="cta"
              >
                <DownloadIcon size={1} style={{ marginRight: '0.5rem' }} />
                Download CSV
              </Button>
            )}
          </div>
        </div>
      </StickyFooter>

      {/* Edit Row Modal */}
      {editModalOpen && editingRowIndex !== null && uploadedFile && (
        <EditRowModal
          isOpen={editModalOpen}
          onClose={() => setEditModalOpen(false)}
          rowIndex={editingRowIndex}
          rowData={uploadedFile.data[editingRowIndex]}
          fieldMapping={fieldMapping}
          template={selectedTemplate}
          errors={validationResult?.errorDetails || []}
          onSave={handleSaveRow}
        />
      )}

      {/* Start New Confirmation Dialog */}
      <ConfirmDiscardDialog
        open={showStartNewConfirm}
        onOpenChange={setShowStartNewConfirm}
        onConfirm={() => window.location.reload()}
        title="Start a new import?"
        description="This will clear all your current data and start over. This action cannot be undone."
        context="current import"
      />
    </Page>
  );
}