import React from 'react';
import { Badge } from '../components/Badge';

export interface ProgressSummaryProps {
  /**
   * Current progress value
   */
  current: number;
  /**
   * Total/target value
   */
  total: number;
  /**
   * Label text
   * @default 'Progress'
   */
  label?: string;
  /**
   * Show percentage badge
   * @default true
   */
  showPercentage?: boolean;
  /**
   * Status variant for styling
   */
  status?: 'success' | 'warning' | 'error' | 'neutral';
  /**
   * Additional className
   */
  className?: string;
}

/**
 * ProgressSummary - Displays progress with label, count, and visual progress bar
 * Uses Salt theme colors for status variants
 */
export const ProgressSummary: React.FC<ProgressSummaryProps> = ({
  current,
  total,
  label = 'Progress',
  showPercentage = true,
  status = 'neutral',
  className
}) => {
  const percentage = total > 0 ? (current / total) * 100 : 0;
  
  const statusColors = {
    success: 'var(--salt-color-green-600)',
    warning: 'var(--salt-color-orange-600)',
    error: 'var(--salt-color-red-600)',
    neutral: 'var(--salt-color-blue-600)',
  };

  const progressColor = statusColors[status];

  return (
    <div className={`mb-6 ${className || ''}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm">{label}</span>
        <div className="flex items-center gap-2">
          <span className="text-sm">{current}/{total}</span>
          {showPercentage && (
            <Badge value={`${percentage.toFixed(0)}%`} />
          )}
        </div>
      </div>
      <div className="w-full rounded-full" style={{ 
        backgroundColor: 'var(--salt-color-gray-200)',
        height: '8px'
      }}>
        <div 
          className="h-full rounded-full transition-all duration-300"
          style={{ 
            width: `${percentage}%`,
            backgroundColor: progressColor
          }}
        />
      </div>
    </div>
  );
};

