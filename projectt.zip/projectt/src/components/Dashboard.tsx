import { Text, H1, H2, H3, H4, Display1 } from '@salt-ds/core';
import { 
  CloudUploadIcon,
  DocumentIcon,
  RefreshIcon,
  SuccessTickIcon,
  ProtectionIcon,
  ClockIcon,
  FolderClosedIcon,
  ScheduleIcon
} from '@salt-ds/icons';
import { Button, Card, Badge } from '../ui';
import { Page, Section, Stack } from '../ui/layout';
import { Tag } from '@salt-ds/core';

interface DashboardProps {
  onStartImport: () => void;
}

export function Dashboard({ onStartImport }: DashboardProps) {
  // Z-index constants
  const Z_INDEX_BADGE = 20;
  const Z_INDEX_CARD = 10;
  const Z_INDEX_BACKGROUND = 0;

  // Badge slot height - space reserved for badge above card
  const BADGE_SLOT_HEIGHT = '24px';

  const steps = [
    {
      Icon: CloudUploadIcon,
      title: 'Upload Data',
      description: 'Import your data from CSV or Excel files'
    },
    {
      Icon: DocumentIcon,
      title: 'Select Template',
      description: 'Choose your target output format'
    },
    {
      Icon: RefreshIcon,
      title: 'Map Fields',
      description: 'Match your data fields to template requirements'
    },
    {
      Icon: SuccessTickIcon,
      title: 'Validate & Export',
      description: 'Review and download your formatted file'
    }
  ];

  return (
    <Page maxWidth="6xl">
      <Stack gap="xl">
        {/* Header */}
        <Section>
          <div style={{ textAlign: 'left' }}>
            <H1 style={{ marginBottom: '0.5rem' }}>
              Data Transformation Tool
            </H1>
            <Text 
              style={{ 
                fontSize: 'var(--salt-text-fontSize-large)',
                color: 'var(--salt-content-secondary-foreground)'
              }}
            >
              Transform and standardize your data with precision. Upload, map, validate, and export in minutes.
            </Text>
          </div>
        </Section>

        {/* Process Steps */}
        <Section title="How it works">
          <div 
            className="grid grid-cols-1 md:grid-cols-4 gap-6"
            style={{ marginTop: '1.5rem' }}
          >
            {steps.map((step, index) => {
              const stepNumber = index + 1;
              const StepIcon = step.Icon;
              return (
                <Card 
                  key={index}
                  variant="primary"
                  hoverable
                  style={{
                    padding: '1.5rem'
                  }}
                >
                  <div className="flex flex-col items-start text-left">
                    {/* Icon Row */}
                    <div className="flex items-center gap-2 mb-3 w-full">
                      <StepIcon 
                        style={{ 
                          width: '24px',
                          height: '24px',
                          color: 'var(--salt-color-accent-foreground)',
                          flexShrink: 0
                        }}
                      />
                    </div>
                    
                    {/* Content */}
                    <H3 style={{ marginBottom: '0.375rem', fontSize: '1.125rem' }}>
                      {stepNumber}. {step.title}
                    </H3>
                    <Text 
                      style={{ 
                        fontSize: 'var(--salt-text-fontSize)',
                        color: 'var(--salt-content-secondary-foreground)'
                      }}
                    >
                      {step.description}
                    </Text>
                  </div>
                </Card>
              );
            })}
          </div>
        </Section>

        {/* CTA Section */}
        <Section>
          <Card variant="primary" style={{ padding: '2rem' }}>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex items-start gap-3 flex-1">
                <div className="flex flex-col">
                  <H3 style={{ marginBottom: '0.75rem' }}>
                    Ready to get started?
                  </H3>
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2">
                      <ProtectionIcon style={{ width: '16px', height: '16px', color: 'var(--salt-color-success-foreground)' }} />
                      <Text style={{ fontSize: 'var(--salt-text-fontSize)' }}>100% Secure</Text>
                    </div>
                    <div className="flex items-center gap-2">
                      <ClockIcon style={{ width: '16px', height: '16px', color: 'var(--salt-color-accent-foreground)' }} />
                      <Text style={{ fontSize: 'var(--salt-text-fontSize)' }}>Within 4 minutes</Text>
                    </div>
                  </div>
                </div>
              </div>
              <Button 
                variant="cta"
                onClick={onStartImport}
                size="large"
              >
                Start Transformation
              </Button>
            </div>
          </Card>
        </Section>

        {/* Feature Cards */}
        <Section>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card variant="primary" style={{ padding: '1.5rem' }}>
              <div className="flex items-start gap-3">
                <FolderClosedIcon 
                  style={{ 
                    width: '24px', 
                    height: '24px', 
                    color: 'var(--salt-color-accent-foreground)',
                    flexShrink: 0
                  }} 
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <H4>
                      Multiple File Formats
                    </H4>
                  </div>
                  <Text 
                    style={{ 
                      fontSize: 'var(--salt-text-fontSize)',
                      marginBottom: '0.75rem',
                      color: 'var(--salt-content-secondary-foreground)'
                    }}
                  >
                    Import from CSV, Excel (XLSX), and more
                  </Text>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Tag category={15}>CSV</Tag>
                    <Tag category={15}>Excel</Tag>
                    <Tag category={15}>XLSX</Tag>
                  </div>
                </div>
              </div>
            </Card>

            <Card variant="primary" style={{ padding: '1.5rem' }}>
              <div className="flex items-start gap-3">
                <ScheduleIcon 
                  style={{ 
                    width: '24px', 
                    height: '24px', 
                    color: 'var(--salt-color-accent-foreground)',
                    flexShrink: 0
                  }} 
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <H4>
                      Coming Soon
                    </H4>
                    <Badge value="New" />
                  </div>
                  <Text 
                    style={{ 
                      fontSize: 'var(--salt-text-fontSize)',
                      marginBottom: '0.75rem',
                      color: 'var(--salt-content-secondary-foreground)'
                    }}
                  >
                    Direct integrations with business platforms
                  </Text>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Tag category={15}>Salesforce</Tag>
                    <Tag category={15}>Workday</Tag>
                    <Tag category={15}>More</Tag>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </Section>
      </Stack>
    </Page>
  );
}
