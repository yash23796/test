import React from 'react';
import { Button } from '../components/Button';

export interface PageHeaderAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'cta' | 'outline' | 'ghost';
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PageHeaderProps {
  /**
   * Page title (H1)
   */
  title: string;
  /**
   * Page description
   */
  description?: string;
  /**
   * Breadcrumbs (optional)
   */
  breadcrumbs?: Array<{
    label: string;
    onClick?: () => void;
  }>;
  /**
   * Primary action (right-aligned)
   */
  primaryAction?: PageHeaderAction;
  /**
   * Secondary actions (right-aligned, before primary)
   */
  secondaryActions?: PageHeaderAction[];
  /**
   * Additional className
   */
  className?: string;
}

/**
 * PageHeader - Standardized page header with title, description, and actions
 * Uses proper heading hierarchy (H1 for page title)
 * Actions are right-aligned, primary action appears last
 */
export const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  description,
  breadcrumbs,
  primaryAction,
  secondaryActions = [],
  className = ''
}) => {
  return (
    <header className={`mb-6 ${className}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          {/* Breadcrumbs */}
          {breadcrumbs && breadcrumbs.length > 0 && (
            <nav className="mb-2" aria-label="Breadcrumb">
              <ol className="flex items-center gap-2 text-sm">
                {breadcrumbs.map((crumb, index) => (
                  <li key={index} className="flex items-center">
                    {index > 0 && (
                      <span className="mx-2" style={{ color: 'var(--salt-color-gray-400)' }}>/</span>
                    )}
                    {crumb.onClick ? (
                      <button
                        onClick={crumb.onClick}
                        className="hover:underline"
                        style={{ color: 'var(--salt-color-gray-600)' }}
                      >
                        {crumb.label}
                      </button>
                    ) : (
                      <span style={{ color: 'var(--salt-color-gray-600)' }}>{crumb.label}</span>
                    )}
                  </li>
                ))}
              </ol>
            </nav>
          )}
          
          {/* Title */}
          <h1 className="text-3xl font-semibold mb-2" style={{ color: 'var(--salt-color-gray-900)' }}>
            {title}
          </h1>
          
          {/* Description */}
          {description && (
            <p className="text-sm" style={{ color: 'var(--salt-color-gray-600)' }}>
              {description}
            </p>
          )}
        </div>
        
        {/* Actions */}
        {(primaryAction || secondaryActions.length > 0) && (
          <div className="flex items-center gap-2 flex-shrink-0">
            {secondaryActions.map((action, index) => (
              <Button
                key={index}
                variant={action.variant || 'outline'}
                onClick={action.onClick}
                icon={action.icon}
                disabled={action.disabled}
              >
                {action.label}
              </Button>
            ))}
            {primaryAction && (
              <Button
                variant={primaryAction.variant || 'primary'}
                onClick={primaryAction.onClick}
                icon={primaryAction.icon}
                disabled={primaryAction.disabled}
              >
                {primaryAction.label}
              </Button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

