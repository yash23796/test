import React from 'react';
import { Button } from '@salt-ds/core';

interface StickyFooterProps {
  onBack?: () => void;
  onNext?: () => void;
  nextLabel?: string;
  backLabel?: string;
  nextDisabled?: boolean;
  hideBack?: boolean;
  hideNext?: boolean;
  children?: React.ReactNode;
}

export function StickyFooter({
  onBack,
  onNext,
  nextLabel = 'Continue',
  backLabel = 'Back',
  nextDisabled = false,
  hideBack = false,
  hideNext = false,
  children
}: StickyFooterProps) {
  return (
    <div 
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        backgroundColor: 'var(--salt-container-primary-background)',
        borderTop: '1px solid var(--salt-separable-primary-borderColor)',
        boxShadow: '0 -2px 8px rgba(0, 0, 0, 0.1)'
      }}
    >
      <div className="max-w-4xl mx-auto px-6 py-4">
        {children || (
          <div className="flex justify-between items-center">
            {!hideBack && onBack && (
              <Button variant="secondary" onClick={onBack}>
                {backLabel}
              </Button>
            )}
            {hideBack && <div />}
            {!hideNext && onNext && (
              <Button
                variant="cta"
                onClick={onNext}
                disabled={nextDisabled}
              >
                {nextLabel}
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

