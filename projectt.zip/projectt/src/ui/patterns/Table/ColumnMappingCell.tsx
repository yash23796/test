import React from 'react';
import { Select, type SelectOption } from '../../components/Select';
import { InlineFieldMessage } from '../InlineFieldMessage';

export interface ColumnMappingCellProps {
  /**
   * Current selected value
   */
  value: string;
  /**
   * Available options for selection
   */
  options: SelectOption[];
  /**
   * onChange handler
   */
  onChange: (value: string) => void;
  /**
   * Placeholder text
   */
  placeholder?: string;
  /**
   * Validation status
   */
  validationStatus?: 'error' | 'warning' | 'success';
  /**
   * Helper text
   */
  helperText?: string;
  /**
   * Error text
   */
  errorText?: string;
  /**
   * Whether field is required
   * @default false
   */
  required?: boolean;
  /**
   * Whether field is disabled
   * @default false
   */
  disabled?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * ColumnMappingCell - Standardized mapping cell with select + helper/error
 * Uses Salt Select and InlineFieldMessage for consistent styling
 */
export const ColumnMappingCell: React.FC<ColumnMappingCellProps> = ({
  value,
  options,
  onChange,
  placeholder = 'Select field to map...',
  validationStatus,
  helperText,
  errorText,
  required = false,
  disabled = false,
  className
}) => {
  const handleChange = (newValue: string) => {
    if (newValue === 'none') {
      onChange('');
    } else {
      onChange(newValue);
    }
  };

  const selectOptions: SelectOption[] = [
    { value: 'none', label: 'No mapping' },
    ...options
  ];

  return (
    <div className={className || ''}>
      <Select
        variant="primary"
        value={value || 'none'}
        options={selectOptions}
        placeholder={placeholder}
        validationStatus={validationStatus}
        disabled={disabled}
        onChange={handleChange}
      />
      <InlineFieldMessage
        helperText={helperText}
        errorText={errorText}
        required={required}
      />
    </div>
  );
};

