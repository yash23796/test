import React from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';
import { CheckCircle, AlertTriangle, Edit } from 'lucide-react';
import { DataTable, RowActions } from './Table';

export interface ValidationError {
  row: number;
  field?: string;
  error: string;
  value?: string | number;
}

export interface ValidationSummaryProps {
  /**
   * Number of valid rows
   */
  valid: number;
  /**
   * Total number of rows
   */
  total: number;
  /**
   * Number of errors
   */
  errors: number;
  /**
   * Error details (optional, for display)
   */
  errorDetails?: ValidationError[];
  /**
   * Show error details section
   * @default false
   */
  showErrorDetails?: boolean;
  /**
   * Callback for re-validate action
   */
  onRevalidate?: () => void;
  /**
   * Callback for edit all action
   */
  onEditAll?: () => void;
  /**
   * Callback for editing a single row
   */
  onEditRow?: (rowIndex: number) => void;
  /**
   * Is validating state
   * @default false
   */
  isValidating?: boolean;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * ValidationSummary - Displays validation results with summary and error details
 * Uses Salt components for consistent styling
 */
export const ValidationSummary: React.FC<ValidationSummaryProps> = ({
  valid,
  total,
  errors,
  errorDetails = [],
  showErrorDetails = false,
  onRevalidate,
  onEditAll,
  onEditRow,
  isValidating = false,
  className
}) => {
  const percentage = total > 0 ? (valid / total) * 100 : 0;
  const hasErrors = errors > 0;

  return (
    <div className={className || ''}>
      {/* Summary Banner */}
      <div className="sticky top-0 z-10 mb-6">
        <Card 
          variant="primary" 
          className="px-6 py-4"
          style={{
            border: `2px solid ${hasErrors ? 'var(--salt-color-red-200)' : 'var(--salt-color-green-200)'}`,
            backgroundColor: hasErrors ? 'var(--salt-color-red-50)' : 'var(--salt-color-green-50)',
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {hasErrors ? (
                <AlertTriangle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--salt-color-red-600)' }} />
              ) : (
                <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--salt-color-green-600)' }} />
              )}
              <div>
                <div className="flex items-center gap-3">
                  <span 
                    className="text-lg font-semibold"
                    style={{ color: hasErrors ? 'var(--salt-color-red-900)' : 'var(--salt-color-green-900)' }}
                  >
                    {valid} of {total} rows valid
                  </span>
                  <span className="text-sm">{percentage.toFixed(1)}%</span>
                </div>
                {hasErrors && (
                  <p className="text-sm mt-0.5" style={{ color: 'var(--salt-color-red-700)' }}>
                    {errors} errors must be fixed before export
                  </p>
                )}
              </div>
            </div>
            {onRevalidate && (
              <Button 
                variant="outline"
                onClick={onRevalidate}
                disabled={isValidating}
                icon={isValidating ? <div className="animate-spin">⟳</div> : undefined}
              >
                Re-validate
              </Button>
            )}
          </div>
        </Card>
      </div>

      {/* Error Details Section */}
      {showErrorDetails && hasErrors && errorDetails.length > 0 && (
        <Card variant="primary" className="p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <h3 className="font-semibold">Error Details</h3>
              <Badge value={`${errors} errors found`} />
            </div>
            {onEditAll && (
              <Button variant="outline" onClick={onEditAll}>
                Edit All Data
              </Button>
            )}
          </div>
          
          <DataTable
            columns={[
              {
                header: 'Row',
                accessor: 'row',
                noWrap: true,
                width: '80px'
              },
              {
                header: 'Error',
                accessor: (error) => (
                  <div>
                    <p className="text-sm">
                      {error.error}
                      {error.value !== undefined && error.value !== null && (
                        <span className="ml-2 text-xs" style={{ color: 'var(--salt-color-gray-600)' }}>
                          | Value: <span className="font-mono">"{String(error.value)}"</span>
                        </span>
                      )}
                    </p>
                  </div>
                ),
                noWrap: false
              },
              {
                header: 'Actions',
                accessor: (error) => onEditRow ? (
                  <RowActions
                    actions={[{
                      label: 'Fix',
                      onClick: () => onEditRow(error.row - 1),
                      icon: <Edit className="w-3 h-3" />
                    }]}
                  />
                ) : null,
                noWrap: true,
                width: '100px'
              }
            ]}
            data={errorDetails.slice(0, 20)}
            getRowKey={(error, index) => `error-${error.row}-${index}`}
            getRowClassName={() => 'hover:bg-red-50/50'}
            emptyState={{
              title: 'No errors found',
              description: 'All rows are valid'
            }}
          />
          
          {errorDetails.length > 20 && (
            <div className="p-4 rounded-lg border mt-4" style={{ 
              borderColor: 'var(--salt-color-gray-200)',
              backgroundColor: 'var(--salt-color-gray-50)'
            }}>
              <p className="text-sm">
                Showing first 20 of {errorDetails.length} total errors.
                {onEditAll && (
                  <Button 
                    variant="ghost"
                    onClick={onEditAll}
                    className="ml-2 h-auto p-0"
                  >
                    View all in editor
                  </Button>
                )}
              </p>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

