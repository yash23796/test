import React from 'react';
import { Card } from '../../components/Card';
import { Progress } from '../../components/Progress';
import { Button } from '../../components/Button';
import { Alert } from '../../components/Alert';
import { X } from 'lucide-react';

export interface UploadProgressNoticeProps {
  /**
   * Upload progress percentage (0-100)
   */
  progress?: number;
  /**
   * Whether upload is in progress
   */
  isUploading: boolean;
  /**
   * Upload status message
   */
  message?: string;
  /**
   * Callback to cancel upload
   */
  onCancel?: () => void;
  /**
   * Error message (if upload failed)
   */
  error?: string;
  /**
   * Success message (if upload completed)
   */
  success?: string;
  /**
   * Additional className
   */
  className?: string;
}

/**
 * UploadProgressNotice - Standardized upload progress indicator
 * Shows progress bar, status message, and cancel option
 */
export const UploadProgressNotice: React.FC<UploadProgressNoticeProps> = ({
  progress,
  isUploading,
  message = 'Processing file...',
  onCancel,
  error,
  success,
  className
}) => {
  if (error) {
    return (
      <Alert severity="error" title="Upload Failed" className={className}>
        {error}
      </Alert>
    );
  }

  if (success) {
    return (
      <Alert severity="success" title="Upload Complete" className={className}>
        {success}
      </Alert>
    );
  }

  if (!isUploading) {
    return null;
  }

  return (
    <Card variant="primary" className={`p-4 ${className || ''}`}>
      <div className="flex items-center justify-between gap-4 mb-3">
        <div className="flex-1">
          <p className="text-sm font-medium mb-1">{message}</p>
          {progress !== undefined && (
            <Progress value={progress} variant="linear" className="mt-2" />
          )}
          {progress === undefined && (
            <Progress variant="linear" className="mt-2" />
          )}
        </div>
        {onCancel && (
          <Button
            variant="ghost"
            onClick={onCancel}
            icon={<X className="w-4 h-4" />}
          />
        )}
      </div>
    </Card>
  );
};

